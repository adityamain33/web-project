// src/pages/user/ScheduleMaintenance.js
import React, { useState } from 'react';
import axios from 'axios';

function ScheduleMaintenance() {
  const [formData, setFormData] = useState({
    deviceName: '',
    maintenanceType: '',
    preferredDate: '',
    preferredTime: '',
    notes: '',
    image: null,
  });

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'image') {
      setFormData((prev) => ({ ...prev, image: files[0] }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const token = localStorage.getItem('token');
    if (!token) return alert('User is not logged in');

    const data = new FormData();
    for (const key in formData) {
      data.append(key, formData[key]);
    }

    try {
      await axios.post(
        'http://localhost:5000/api/maintenance/schedule',
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
        }
      );
      alert('Maintenance scheduled successfully!');
      setFormData({
        deviceName: '',
        maintenanceType: '',
        preferredDate: '',
        preferredTime: '',
        notes: '',
        image: null,
      });
    } catch (err) {
      console.error(err);
      alert('Error scheduling maintenance');
    }
  };

  return (
    <div className="container my-5">
      <div className="card p-4 shadow-sm">
        <h3 className="text-center text-success mb-4">Schedule Maintenance</h3>
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="mb-3">
            <label className="form-label">Device Name</label>
            <input
              type="text"
              className="form-control"
              name="deviceName"
              value={formData.deviceName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Maintenance Type</label>
            <select
              className="form-select"
              name="maintenanceType"
              value={formData.maintenanceType}
              onChange={handleChange}
              required
            >
              <option value="">-- Select Type --</option>
              <option value="Cleaning">Cleaning</option>
              <option value="Repair">Repair</option>
              <option value="Software Update">Software Update</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="row">
            <div className="mb-3 col-md-6">
              <label className="form-label">Preferred Date</label>
              <input
                type="date"
                className="form-control"
                name="preferredDate"
                value={formData.preferredDate}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3 col-md-6">
              <label className="form-label">Preferred Time Slot</label>
              <input
                type="time"
                className="form-control"
                name="preferredTime"
                value={formData.preferredTime}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="mb-3">
            <label className="form-label">Additional Notes</label>
            <textarea
              className="form-control"
              name="notes"
              rows="3"
              value={formData.notes}
              onChange={handleChange}
            ></textarea>
          </div>

          <div className="mb-4">
            <label className="form-label">Upload Image (optional)</label>
            <input
              type="file"
              className="form-control"
              name="image"
              accept="image/*"
              onChange={handleChange}
            />
          </div>

          <div className="d-grid">
            <button className="btn btn-success" type="submit">
              Submit Request
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ScheduleMaintenance;
