import React, { useEffect, useState } from 'react';
import { Card, Row, Col, Badge } from 'react-bootstrap';
import axios from 'axios';
import { FaCheckCircle, FaHourglassHalf, FaClipboardList } from 'react-icons/fa';

function RecyclerDashboard() {
  const [stats, setStats] = useState({
    totalAssigned: 0,
    completed: 0,
    pending: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('/api/recycler/dashboard-stats', {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (response.data.success) {
          setStats(response.data.data);
        } else {
          console.error('Failed to fetch stats:', response.data.message);
        }
      } catch (error) {
        console.error('Error fetching recycler dashboard stats:', error);
      }
    };

    fetchStats();
  }, []);

  return (
    <>
      <h4 className="text-success mb-4">Recycler Dashboard</h4>
      <Row className="mb-4">
        <Col md={4} className="mb-3">
          <Card className="p-4 shadow-sm border-start border-success border-5">
            <div className="d-flex align-items-center">
              <FaClipboardList size={40} className="text-success me-3" />
              <div>
                <h6 className="mb-1 text-muted">Total Assigned</h6>
                <h4 className="mb-0">{stats.totalAssigned}</h4>
                <Badge bg="success" className="mt-2">Allotted Tasks</Badge>
              </div>
            </div>
          </Card>
        </Col>

        <Col md={4} className="mb-3">
          <Card className="p-4 shadow-sm border-start border-primary border-5">
            <div className="d-flex align-items-center">
              <FaCheckCircle size={40} className="text-primary me-3" />
              <div>
                <h6 className="mb-1 text-muted">Completed Pickups</h6>
                <h4 className="mb-0">{stats.completed}</h4>
                <Badge bg="primary" className="mt-2">Completed</Badge>
              </div>
            </div>
          </Card>
        </Col>

        <Col md={4} className="mb-3">
          <Card className="p-4 shadow-sm border-start border-warning border-5">
            <div className="d-flex align-items-center">
              <FaHourglassHalf size={40} className="text-warning me-3" />
              <div>
                <h6 className="mb-1 text-muted">Pending Pickups</h6>
                <h4 className="mb-0">{stats.pending}</h4>
                <Badge bg="warning" text="dark" className="mt-2">Pending</Badge>
              </div>
            </div>
          </Card>
        </Col>
      </Row>
    </>
  );
}

export default RecyclerDashboard;
