import React, { useState } from "react";
import axios from "axios";

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userMessage, setUserMessage] = useState("");
  const [chatMessages, setChatMessages] = useState([
    { role: "bot", content: "Hello! How can I assist you today?" },
  ]);

  const toggleChatbot = () => {
    console.log('Chatbot button clicked');  // Check if the button is being clicked
    setIsOpen(!isOpen);
  };

  const handleSendMessage = async () => {
    if (!userMessage.trim()) return;
  
    // ✅ Add user's message
    const newMessages = [...chatMessages, { role: "user", content: userMessage }];
    setChatMessages(newMessages);
  
    try {
      const response = await axios.post("http://localhost:5000/api/chat", {
        message: userMessage,
      });
  
      // ✅ Check response
      const botReply = response.data?.message || "🤖 Sorry, I couldn't understand.";
  
      // ✅ Add bot's reply
      setChatMessages([
        ...newMessages,
        { role: "bot", content: botReply },
      ]);
  
      // ✅ Clear input
      setUserMessage("");
    } catch (error) {
      console.error("🔴 Error sending message:", error);
      setChatMessages([
        ...newMessages,
        { role: "bot", content: "❌ Error reaching chatbot. Please try again." },
      ]);
    }
  };
  

  return (
    <>
      {/* Chatbot Button */}
      <div
        onClick={toggleChatbot}
        style={{
          position: "fixed",
          bottom: "20px",
          right: "20px",
          backgroundColor: "#28a745",
          color: "white",
          borderRadius: "50%",
          width: "60px",
          height: "60px",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          cursor: "pointer",
          boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
          zIndex: 1000,  // Ensuring the chatbot button is on top of other elements
        }}
      >
        <span style={{ fontSize: "24px" }}>💬</span>
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div
          className="chat-window"
          style={{
            position: "fixed",
            bottom: "80px",
            right: "20px",
            width: "300px",
            height: "400px",
            backgroundColor: "white",
            boxShadow: "0 0 15px rgba(0, 0, 0, 0.1)",
            borderRadius: "8px",
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            padding: "10px",
            zIndex: 1000,  // Ensure chat window is on top
          }}
        >
          {/* Chat Header */}
          <div
            style={{
              backgroundColor: "#28a745",
              color: "white",
              padding: "10px",
              textAlign: "center",
              fontWeight: "bold",
            }}
          >
            Chatbot
            <button
              onClick={toggleChatbot}
              style={{
                background: "none",
                border: "none",
                color: "white",
                position: "absolute",
                top: "10px",
                right: "10px",
                fontSize: "18px",
                cursor: "pointer",
              }}
            >
              ✖
            </button>
          </div>

          {/* Chat Messages */}
          <div
            className="chat-messages"
            style={{
              flexGrow: 1,
              overflowY: "scroll",
              padding: "10px",
              borderBottom: "1px solid #ddd",
            }}
          >
            {chatMessages.map((msg, index) => (
              <p
                key={index}
                style={{
                  color: msg.role === "user" ? "#555" : "#28a745",
                  textAlign: msg.role === "user" ? "right" : "left",
                  padding: "5px",
                }}
              >
                {msg.content}
              </p>
            ))}
          </div>

          {/* Chat Input */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              padding: "10px",
              borderTop: "1px solid #ddd",
            }}
          >
            <input
              type="text"
              value={userMessage}
              onChange={(e) => setUserMessage(e.target.value)}
              placeholder="Type a message..."
              style={{
                width: "80%",
                padding: "10px",
                borderRadius: "5px",
                border: "1px solid #ddd",
              }}
            />
            <button
              onClick={handleSendMessage}
              style={{
                backgroundColor: "#28a745",
                color: "white",
                border: "none",
                borderRadius: "5px",
                padding: "10px",
                marginLeft: "10px",
                cursor: "pointer",
              }}
            >
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
