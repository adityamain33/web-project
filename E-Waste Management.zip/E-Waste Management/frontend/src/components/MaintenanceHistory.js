import React, { useEffect, useState } from 'react';
import axios from 'axios';

function MaintenanceHistory() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await axios.get(
          'http://localhost:5000/api/maintenance/history',
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setRecords(response.data.reverse());
      } catch (err) {
        console.error('Error fetching maintenance history:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, []);

  return (
    <div className="container my-4">
      <h3 className="text-success text-center mb-4">Maintenance History</h3>

      {loading ? (
        <div className="text-center my-5">
          <div className="spinner-border text-success" role="status"></div>
        </div>
      ) : records.length === 0 ? (
        <p className="text-muted text-center">No maintenance records found.</p>
      ) : (
        <div className="row">
          {records.map((record, index) => (
            <div className="col-md-6 mb-4" key={index}>
              <div className="card shadow-sm border-0">
                <div className="card-body">
                  <h5 className="card-title text-success">Scheduled Maintenance</h5>
                  <p><strong>Asset:</strong> {record.assetId?.deviceName || 'N/A'}</p>
                  <p><strong>Technician:</strong> {record.technicianId?.name || 'Not Assigned'}</p>
                  <p><strong>Date:</strong> {record.scheduledDate}</p>
                  <p><strong>Time Slot:</strong> {record.scheduledTime}</p>
                  <p>
                    <strong>Status:</strong>{' '}
                    <span className={`badge bg-${record.status === 'Completed' ? 'success' : 'info'}`}>
                      {record.status}
                    </span>
                  </p>
                  {record.notes && <p><strong>Notes:</strong> {record.notes}</p>}
                  <p className="text-muted small mb-0">
                    Scheduled on: {new Date(record.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default MaintenanceHistory;
