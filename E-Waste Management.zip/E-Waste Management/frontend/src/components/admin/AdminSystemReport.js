import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import { Button, Form, Table } from 'react-bootstrap';

const AdminSystemReport = () => {
  const [report, setReport] = useState(null);
  const [range, setRange] = useState('monthly');
  const [loading, setLoading] = useState(false);
  const reportRef = useRef();

  const fetchReport = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`/api/admin/system-report?range=${range}`);
      setReport(res.data);
    } catch (err) {
      console.error('Failed to fetch report:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [range]);

  const handlePrint = () => {
    const printContent = reportRef.current.innerHTML;
    const originalContent = document.body.innerHTML;

    document.body.innerHTML = printContent;
    window.print();
    document.body.innerHTML = originalContent;
    window.location.reload(); // Refresh page to restore events/UI
  };

  return (
    <div className="container mt-4">
      <h4 className="fw-bold mb-3">📊 E-Waste System Report</h4>

      <Form.Select
        value={range}
        onChange={e => setRange(e.target.value)}
        className="mb-3"
        style={{ maxWidth: '300px' }}
      >
        <option value="monthly">📅 Monthly</option>
        <option value="quarterly">📆 Quarterly</option>
        <option value="yearly">📈 Yearly</option>
      </Form.Select>

      {loading ? (
        <p>Loading...</p>
      ) : report ? (
        <div ref={reportRef} className="p-3 bg-white rounded shadow-sm border">
          <h5 className="mb-3">📅 <strong>{range.toUpperCase()} Data</strong></h5>
          <Table striped bordered responsive>
            <tbody>
              <tr><td><strong>Pickup Requests</strong></td><td>{report.pickupCount}</td></tr>
              <tr><td><strong>Completed Pickups</strong></td><td>{report.completedPickups}</td></tr>
              <tr><td><strong>Maintenance Requests</strong></td><td>{report.maintenanceCount}</td></tr>
              <tr><td><strong>New Users</strong></td><td>{report.newUsers}</td></tr>
              <tr><td><strong>New Subscriptions</strong></td><td>{report.subscriptions}</td></tr>
              <tr><td><strong>New Recyclers</strong></td><td>{report.recyclerCount}</td></tr>
              <tr><td><strong>New Technicians</strong></td><td>{report.technicianCount}</td></tr>
              <tr><td><strong>New Assets Added</strong></td><td>{report.totalAssets}</td></tr>
            </tbody>
          </Table>

          <h5 className="mt-4 mb-3">📊 <strong>Total System Data</strong></h5>
          <Table striped bordered responsive>
            <tbody>
              <tr><td><strong>Total Pickup Requests</strong></td><td>{report.totalPickups}</td></tr>
              <tr><td><strong>Total Completed Pickups</strong></td><td>{report.totalCompleted}</td></tr>
              <tr><td><strong>Total Maintenance Requests</strong></td><td>{report.totalMaintenance}</td></tr>
              <tr><td><strong>Total Users</strong></td><td>{report.totalUsers}</td></tr>
              <tr><td><strong>Total Subscriptions</strong></td><td>{report.totalSubscriptions}</td></tr>
              <tr><td><strong>Total Recyclers</strong></td><td>{report.totalRecyclers}</td></tr>
              <tr><td><strong>Total Technicians</strong></td><td>{report.totalTechnicians}</td></tr>
              <tr><td><strong>Total Assets</strong></td><td>{report.allAssets}</td></tr>
            </tbody>
          </Table>
        </div>
      ) : (
        <p>No data available</p>
      )}

      {report && (
        <Button variant="success" onClick={handlePrint} className="mt-3">
          🖨 Print Report
        </Button>
      )}
    </div>
  );
};

export default AdminSystemReport;
