import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminInventory = () => {
  const [inventory, setInventory] = useState([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchInventory = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/admin/inventory', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setInventory(res.data);
      } catch (err) {
        console.error('Error fetching inventory:', err);
        alert('Failed to load inventory data');
      }
    };

    fetchInventory();
  }, []);

  // Filter + Search Logic (without modifying the original mapping)
  const filteredInventory = inventory.filter(item => {
    const status = (item.status || item.pickupStatus || '').toLowerCase();
    const category = item.category?.toLowerCase() || '';
    const name = item.itemName?.toLowerCase() || '';
    const searchMatch = name.includes(searchQuery.toLowerCase());
    const statusMatch = statusFilter ? status === statusFilter.toLowerCase() : true;
    const categoryMatch = categoryFilter ? category === categoryFilter.toLowerCase() : true;
    return searchMatch && statusMatch && categoryMatch;
  });

  return (
    <div className="container mt-4">
      <h2>📦 Inventory Records</h2>

      {/* Search and Filters */}
      <div className="row mb-3">
        <div className="col-md-3">
          <input
            type="text"
            placeholder="Search by item name"
            className="form-control"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="col-md-3">
          <select
            className="form-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="">All Statuses</option>
            <option value="available">Available</option>
            <option value="picked-up">Picked-Up</option>
            <option value="disposed">Disposed</option>
          </select>
        </div>
        <div className="col-md-3">
          <select
            className="form-select"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            <option value="">All Categories</option>
            <option value="Electronics">Electronics</option>
            <option value="Battery">Battery</option>
            <option value="Plastic">Plastic</option>
          </select>
        </div>
      </div>

      {/* Original Table (Unchanged) */}
      <div className="table-responsive">
        <table className="table table-bordered table-hover mt-3">
          <thead className="table-light">
            <tr>
              <th>#</th>
              <th>Added By</th>
              <th>Item Name</th>
              <th>Category</th>
              <th>Quantity</th>
              <th>Condition</th>
              <th>Status</th>
              <th>Added On</th>
            </tr>
          </thead>
          <tbody>
            {filteredInventory.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center">No inventory records found</td>
              </tr>
            ) : (
              filteredInventory.map((item, index) => (
                <tr key={item._id}>
                  <td>{index + 1}</td>
                  <td>{item.addedBy?.name || 'N/A'}</td>
                  <td>{item.itemName}</td>
                  <td>{item.category}</td>
                  <td>{item.quantity}</td>
                  <td>{item.condition || 'N/A'}</td>
                  <td>{item.status || item.pickupStatus || 'N/A'}</td>
                  <td>{item.addedOn ? new Date(item.addedOn).toLocaleDateString() : 'N/A'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminInventory;
