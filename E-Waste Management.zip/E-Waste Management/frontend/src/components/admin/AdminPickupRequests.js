import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Table, Form, Row, Col, Button } from 'react-bootstrap';

const PickupRequests = () => {
  const [requests, setRequests] = useState([]);
  const [recyclers, setRecyclers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [availableMonths, setAvailableMonths] = useState([]);

  const token = localStorage.getItem('token');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [pickupRes, recyclerRes] = await Promise.all([
        axios.get('http://localhost:5000/api/admin/pickups', {
          headers: { Authorization: `Bearer ${token}` },
        }),
        axios.get('http://localhost:5000/api/admin/recyclers', {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      setRequests(pickupRes.data);
      setRecyclers(recyclerRes.data);

      // Prepare unique month-year filters
      const months = pickupRes.data.map(r => {
        const d = new Date(r.preferredDate);
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      });
      setAvailableMonths([...new Set(months)]);
    } catch (error) {
      console.error('Error fetching data:', error);
      alert('Error fetching pickup requests or recyclers');
    }
  };

  const assignRecycler = async (requestId, recyclerId) => {
    try {
      await axios.put(
        `http://localhost:5000/api/admin/pickups/${requestId}/assign`,
        { recyclerId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      await fetchData(); // Refresh
    } catch (err) {
      console.error('Error assigning recycler:', err.response?.data || err.message);
      alert('Error assigning recycler');
    }
  };

  // Apply filters
  const filteredRequests = requests.filter(req => {
    const combinedText = `${req.userId?.name || ''} ${req.itemName} ${req.category}`.toLowerCase();
    const matchesSearch = combinedText.includes(searchTerm.toLowerCase());

    const d = new Date(req.preferredDate);
    const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const matchesMonth = monthFilter ? monthKey === monthFilter : true;

    return matchesSearch && matchesMonth;
  });

  return (
    <div className="container mt-4">
      <h3 className="mb-4">Pickup Requests</h3>

      <Row className="mb-3">
        <Col md={6}>
          <Form.Control
            placeholder="Search by user, item, category..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </Col>
        <Col md={4}>
          <Form.Select
            value={monthFilter}
            onChange={(e) => setMonthFilter(e.target.value)}
          >
            <option value="">Filter by Month</option>
            {availableMonths.map(m => (
              <option key={m} value={m}>
                {new Date(m + '-01').toLocaleString('default', {
                  month: 'long',
                  year: 'numeric',
                })}
              </option>
            ))}
          </Form.Select>
        </Col>
        <Col md={2}>
          <Button variant="secondary" onClick={() => { setSearchTerm(''); setMonthFilter(''); }}>
            Reset
          </Button>
        </Col>
      </Row>

      <Table striped bordered hover responsive>
        <thead className="table-success">
          <tr>
            <th>#</th>
            <th>User</th>
            <th>Item</th>
            <th>Category</th>
            <th>Qty</th>
            <th>Address</th>
            <th>Date</th>
            <th>Time Slot</th>
            <th>Status</th>
            <th>Assigned Recycler</th>
            <th>Assign</th>
          </tr>
        </thead>
        <tbody>
          {filteredRequests.length > 0 ? (
            filteredRequests.map((req, idx) => (
              <tr key={req._id}>
                <td>{idx + 1}</td>
                <td>{req.userId?.name || 'Unknown'}</td>
                <td>{req.itemName}</td>
                <td>{req.category}</td>
                <td>{req.quantity}</td>
                <td>{req.address}</td>
                <td>{new Date(req.preferredDate).toLocaleDateString()}</td>
                <td>{req.timeSlot}</td>
                <td>{req.status}</td>
                <td>{req.assignedRecycler?.name || 'Not assigned'}</td>
                <td>
                  <Form.Select
                    size="sm"
                    onChange={(e) => assignRecycler(req._id, e.target.value)}
                    disabled={!!req.assignedRecycler}
                    defaultValue=""
                  >
                    <option disabled value="">
                      {req.assignedRecycler ? 'Already Assigned' : 'Select Recycler'}
                    </option>
                    {recyclers.map((r) => (
                      <option key={r._id} value={r._id}>
                        {r.name}
                      </option>
                    ))}
                  </Form.Select>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="11" className="text-center">
                No pickup requests available.
              </td>
            </tr>
          )}
        </tbody>
      </Table>
    </div>
  );
};

export default PickupRequests;
