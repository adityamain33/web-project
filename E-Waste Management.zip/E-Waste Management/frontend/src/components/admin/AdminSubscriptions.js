import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminSubscriptions = () => {
  const [subscriptions, setSubscriptions] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [planFilter, setPlanFilter] = useState('');

  const fetchSubscriptions = async () => {
    try {
      const res = await axios.get('/api/admin/all-subscriptions');
      setSubscriptions(res.data);
      setFiltered(res.data); // initially show all
    } catch (err) {
      console.error('Error fetching subscriptions:', err);
      setError('Failed to load subscription data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubscriptions();
  }, []);

  // Search + Filter logic
  useEffect(() => {
    let result = subscriptions;

    if (searchQuery) {
      result = result.filter((sub) => {
        const name = sub.userId?.name?.toLowerCase() || '';
        const email = sub.userId?.email?.toLowerCase() || '';
        return (
          name.includes(searchQuery.toLowerCase()) ||
          email.includes(searchQuery.toLowerCase())
        );
      });
    }

    if (planFilter) {
      result = result.filter((sub) => sub.planId === planFilter);
    }

    setFiltered(result);
  }, [searchQuery, planFilter, subscriptions]);

  if (loading) return <p>Loading subscriptions...</p>;
  if (error) return <p className="text-danger">{error}</p>;

  return (
    <div className="container mt-4">
      <h4 className="mb-4 fw-bold">📋 Subscription Report</h4>

      {/* Search & Filter Controls */}
      <div className="row mb-3">
        <div className="col-md-4">
          <input
            type="text"
            placeholder="Search by name or email"
            className="form-control"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <select
            className="form-select"
            value={planFilter}
            onChange={(e) => setPlanFilter(e.target.value)}
          >
            <option value="">All Plans</option>
            <option value="Basic">Basic</option>
            <option value="Standard">Standard</option>
            <option value="Premium">Premium</option>
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <p>No subscriptions found.</p>
      ) : (
        <div className="table-responsive">
          <table className="table table-bordered table-striped">
            <thead className="table-dark">
              <tr>
                <th>#</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Plan</th>
                <th>Pickups Left</th>
                <th>Expiry Date</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((sub, index) => (
                <tr key={sub._id}>
                  <td>{index + 1}</td>
                  <td>{sub.userId?.name || 'N/A'}</td>
                  <td>{sub.userId?.email || 'N/A'}</td>
                  <td>{sub.planId || 'N/A'}</td>
                  <td>{sub.remainingPickups}</td>
                  <td>{new Date(sub.validTill).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminSubscriptions;
