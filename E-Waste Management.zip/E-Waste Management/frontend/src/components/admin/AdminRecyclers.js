import React, { useEffect, useState } from 'react';
import { Table, Button, Form, Row, Col } from 'react-bootstrap';
import axios from 'axios';

const AdminRecyclers = () => {
  const [recyclers, setRecyclers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [availableMonths, setAvailableMonths] = useState([]);

  const token = localStorage.getItem('token');

  const fetchRecyclers = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/admin/recyclers', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setRecyclers(res.data);

      // Generate available months from createdAt
      const months = res.data.map(r => {
        const d = new Date(r.createdAt);
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      });
      setAvailableMonths([...new Set(months)]);
    } catch (err) {
      console.error('Error fetching recyclers:', err);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this recycler?')) {
      try {
        await axios.delete(`http://localhost:5000/api/admin/recyclers/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        fetchRecyclers();
      } catch (err) {
        console.error('Error deleting recycler:', err);
      }
    }
  };

  useEffect(() => {
    fetchRecyclers();
  }, []);

  const filteredRecyclers = recyclers.filter(r => {
    const matchSearch = `${r.name} ${r.email} ${r.location}`.toLowerCase().includes(searchTerm.toLowerCase());
    const createdMonth = new Date(r.createdAt);
    const monthKey = `${createdMonth.getFullYear()}-${String(createdMonth.getMonth() + 1).padStart(2, '0')}`;
    const matchMonth = monthFilter ? monthKey === monthFilter : true;
    return matchSearch && matchMonth;
  });

  return (
    <div className="p-4">
      <h3 className="mb-4">All Recyclers</h3>

      <Row className="mb-3">
        <Col md={6}>
          <Form.Control
            type="text"
            placeholder="Search by name, email, location..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </Col>
        <Col md={4}>
          <Form.Select value={monthFilter} onChange={e => setMonthFilter(e.target.value)}>
            <option value="">Filter by Signup Month</option>
            {availableMonths.map(m => (
              <option key={m} value={m}>
                {new Date(m + '-01').toLocaleString('default', { month: 'long', year: 'numeric' })}
              </option>
            ))}
          </Form.Select>
        </Col>
        <Col md={2}>
          <Button variant="secondary" onClick={() => { setSearchTerm(''); setMonthFilter(''); }}>Reset</Button>
        </Col>
      </Row>

      <Table bordered hover responsive>
        <thead className="table-success">
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Location</th>
            <th style={{ width: '120px' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredRecyclers.length === 0 ? (
            <tr><td colSpan="5" className="text-center">No recyclers found.</td></tr>
          ) : (
            filteredRecyclers.map((recycler, index) => (
              <tr key={recycler._id}>
                <td>{index + 1}</td>
                <td>{recycler.name}</td>
                <td>{recycler.email}</td>
                <td>{recycler.location}</td>
                <td>
                  <Button variant="danger" size="sm" onClick={() => handleDelete(recycler._id)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </Table>
    </div>
  );
};

export default AdminRecyclers;
