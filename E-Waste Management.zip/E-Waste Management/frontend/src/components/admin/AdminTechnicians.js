import React, { useEffect, useState } from 'react';
import { Table, Button, Modal, Form, Row, Col } from 'react-bootstrap';
import axios from 'axios';

const AdminTechnicians = () => {
  const [technicians, setTechnicians] = useState([]);
  const [users, setUsers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedTechnician, setSelectedTechnician] = useState(null);
  const [selectedUser, setSelectedUser] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [availableMonths, setAvailableMonths] = useState([]);

  const token = localStorage.getItem('token');

  const fetchTechnicians = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/admin/technicians', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTechnicians(res.data);

      const months = res.data.map(t => {
        const d = new Date(t.createdAt);
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      });
      setAvailableMonths([...new Set(months)]);
    } catch (err) {
      console.error('Error fetching technicians:', err);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/admin/users', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers(res.data);
    } catch (err) {
      console.error('Error fetching users:', err);
    }
  };

  useEffect(() => {
    fetchTechnicians();
    fetchUsers();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this technician?')) {
      try {
        await axios.delete(`http://localhost:5000/api/users/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        fetchTechnicians();
      } catch (err) {
        console.error('Error deleting technician:', err);
      }
    }
  };

  const handleAssignClick = (technician) => {
    setSelectedTechnician(technician);
    setSelectedUser('');
    setShowModal(true);
  };

  const handleAssignSubmit = async () => {
    if (!selectedUser) return alert('Please select a user to assign.');
    try {
      await axios.patch(
        `http://localhost:5000/api/admin/technicians/assign-user/${selectedTechnician._id}`,
        { userId: selectedUser },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('User assigned successfully!');
      setShowModal(false);
      fetchTechnicians();
    } catch (err) {
      console.error('Error assigning user:', err);
      alert('Failed to assign user.');
    }
  };

  const filteredTechs = technicians.filter(t => {
    const matchSearch = `${t.name} ${t.email} ${t.role}`.toLowerCase().includes(searchTerm.toLowerCase());
    const createdMonth = new Date(t.createdAt);
    const monthKey = `${createdMonth.getFullYear()}-${String(createdMonth.getMonth() + 1).padStart(2, '0')}`;
    const matchMonth = monthFilter ? monthFilter === monthKey : true;
    return matchSearch && matchMonth;
  });

  return (
    <div className="p-4">
      <h3 className="mb-4">All Technicians</h3>

      <Row className="mb-3">
        <Col md={6}>
          <Form.Control
            type="text"
            placeholder="Search by name, email, or role..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </Col>
        <Col md={4}>
          <Form.Select value={monthFilter} onChange={e => setMonthFilter(e.target.value)}>
            <option value="">Filter by Signup Month</option>
            {availableMonths.map(month => (
              <option key={month} value={month}>
                {new Date(`${month}-01`).toLocaleString('default', { month: 'long', year: 'numeric' })}
              </option>
            ))}
          </Form.Select>
        </Col>
        <Col md={2}>
          <Button variant="secondary" onClick={() => {
            setSearchTerm('');
            setMonthFilter('');
          }}>
            Reset
          </Button>
        </Col>
      </Row>

      <Table bordered hover responsive>
        <thead className="table-success">
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Assigned User</th>
            <th style={{ width: '220px' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredTechs.length === 0 ? (
            <tr>
              <td colSpan="6" className="text-center">No technicians found.</td>
            </tr>
          ) : (
            filteredTechs.map((tech, index) => (
              <tr key={tech._id}>
                <td>{index + 1}</td>
                <td>{tech.name}</td>
                <td>{tech.email}</td>
                <td>{tech.role}</td>
                <td>
                  {tech.assignedUser ? `${tech.assignedUser.name} (${tech.assignedUser.email})` : 'None'}
                </td>
                <td>
                  <Button variant="info" size="sm" className="me-2" onClick={() => handleAssignClick(tech)}>
                    Assign
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => handleDelete(tech._id)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </Table>

      {/* Assign Modal */}
      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Assign User to Technician</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Select
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
          >
            <option value="">Select user</option>
            {users.map(user => (
              <option key={user._id} value={user._id}>
                {user.name} ({user.email})
              </option>
            ))}
          </Form.Select>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancel
          </Button>
          <Button variant="success" onClick={handleAssignSubmit}>
            Assign
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default AdminTechnicians;
