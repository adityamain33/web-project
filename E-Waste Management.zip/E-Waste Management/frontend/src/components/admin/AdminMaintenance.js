import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Table, Badge, Form, Row, Col } from 'react-bootstrap';

const AdminMaintenance = () => {
  const [records, setRecords] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    const fetchMaintenance = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/admin/maintenance', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setRecords(res.data);
      } catch (err) {
        console.error('Error fetching maintenance:', err);
        alert('Failed to load maintenance records');
      }
    };

    fetchMaintenance();
  }, []);

  // Filtered records by search and status
  const filteredRecords = records.filter((rec) => {
  const combined = `${rec.userId?.name || ''} ${rec.assetId?.deviceName || ''} ${rec.issueDescription}`.toLowerCase();
  const matchesSearch = combined.includes(searchTerm.toLowerCase());
  const matchesStatus = statusFilter
    ? rec.status?.trim().toLowerCase() === statusFilter.toLowerCase()
    : true;
  return matchesSearch && matchesStatus;
});


  const getBadgeVariant = (status) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'in progress':
        return 'warning';
      case 'pending':
        return 'secondary';
      default:
        return 'dark';
    }
  };

  return (
    <div className="container mt-4">
      <h3 className="mb-4">Maintenance Records</h3>

      <Row className="mb-3">
        <Col md={6}>
          <Form.Control
            placeholder="Search by user, item or issue..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </Col>
        <Col md={4}>
          <Form.Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="">Filter by Status</option>
            <option value="pending">Pending</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
          </Form.Select>
        </Col>
      </Row>

      <Table striped bordered hover responsive>
        <thead>
          <tr>
            <th>#</th>
            <th>User</th>
            <th>Item</th>
            <th>Issue</th>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {filteredRecords.length > 0 ? (
            filteredRecords.map((rec, idx) => (
              <tr key={rec._id}>
                <td>{idx + 1}</td>
                <td>{rec.userId?.name || 'Unknown'}</td>
                <td>{rec.assetId?.deviceName}</td>
                <td>{rec.issueDescription}</td>
                <td>{new Date(rec.scheduledDate).toLocaleDateString()}</td>
                <td>
                  <Badge bg={getBadgeVariant(rec.status)}>
                    {rec.status}
                  </Badge>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6" className="text-center">No maintenance records found</td>
            </tr>
          )}
        </tbody>
      </Table>
    </div>
  );
};

export default AdminMaintenance;
