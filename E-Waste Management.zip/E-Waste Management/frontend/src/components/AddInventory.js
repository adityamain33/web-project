import React, { useState } from 'react';
import axios from 'axios';

function AddAssets() {
  const initialState = {
    deviceName: '',
    category: '',
    quantity: 1,
    brand: '',
    modelNumber: '',
    purchaseYear: '',
    warrantyStatus: '',
    condition: '',
    description: '',
  };

  const [formData, setFormData] = useState(initialState);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCancel = () => {
    if (window.confirm('Are you sure you want to clear the form?')) {
      setFormData(initialState);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const token = localStorage.getItem('token');
    if (!token) return alert('User is not logged in');

    try {
      await axios.post('http://localhost:5000/api/inventory/add', formData, {
        headers: { Authorization: `Bearer ${token}` },
      });

      alert('Asset added successfully!');
      setFormData(initialState);
    } catch (error) {
      console.error('Error adding inventory:', error);
      if (error.response?.data?.message) {
        alert(`Error: ${error.response.data.message}`);
      } else {
        alert('Error adding asset');
      }
    }
  };

  return (
    <div className="container my-5 d-flex justify-content-center">
      <div className="card shadow-sm p-4" style={{ maxWidth: '800px', width: '100%' }}>
        <h2 className="mb-4 text-success text-center">Add Asset</h2>
        <form onSubmit={handleSubmit}>
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Device Name</label>
              <input
                type="text"
                className="form-control"
                name="deviceName"
                value={formData.deviceName}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Category</label>
              <select
                className="form-select"
                name="category"
                value={formData.category}
                onChange={handleChange}
                required
              >
                <option value="">-- Select Category --</option>
                <option value="Mobile">Mobile</option>
                <option value="Laptop">Laptop</option>
                <option value="Tablet">Tablet</option>
                <option value="TV">TV</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="col-md-6">
              <label className="form-label">Quantity</label>
              <input
                type="number"
                className="form-control"
                name="quantity"
                min="1"
                value={formData.quantity}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Condition</label>
              <select
                className="form-select"
                name="condition"
                value={formData.condition}
                onChange={handleChange}
                required
              >
                <option value="">-- Select Condition --</option>
                <option value="Working">Working</option>
                <option value="Damaged">Damaged</option>
                <option value="Dead">Dead</option>
              </select>
            </div>

            <div className="col-md-6">
              <label className="form-label">Brand</label>
              <input
                type="text"
                className="form-control"
                name="brand"
                value={formData.brand}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Model Number</label>
              <input
                type="text"
                className="form-control"
                name="modelNumber"
                value={formData.modelNumber}
                onChange={handleChange}
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Purchase Year</label>
              <input
                type="number"
                className="form-control"
                name="purchaseYear"
                min="2000"
                max={new Date().getFullYear()}
                value={formData.purchaseYear}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Warranty Status</label>
              <select
                className="form-select"
                name="warrantyStatus"
                value={formData.warrantyStatus}
                onChange={handleChange}
                required
              >
                <option value="">-- Select --</option>
                <option value="Valid">Valid</option>
                <option value="Expired">Expired</option>
              </select>
            </div>

            <div className="col-12">
              <label className="form-label">Additional Notes</label>
              <textarea
                className="form-control"
                name="description"
                rows="2"
                value={formData.description}
                onChange={handleChange}
              ></textarea>
            </div>
          </div>

          <div className="mt-4 d-flex justify-content-end gap-2">
            <button type="button" className="btn btn-outline-secondary btn-sm" onClick={handleCancel}>
              Cancel
            </button>
            <button type="submit" className="btn btn-success btn-sm">
              Add Asset
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default AddAssets;
