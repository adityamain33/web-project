// src/components/UpdateStatus.js
import React, { useState } from 'react';
import { Table, Button, Form } from 'react-bootstrap';

function UpdateStatus() {
  const [pickups, setPickups] = useState([
    {
      id: 1,
      item: 'CRT Monitor',
      quantity: 1,
      address: '789 Tech Lane',
      status: 'Pending',
    },
    {
      id: 2,
      item: 'Washing Machine',
      quantity: 1,
      address: '101 Eco Heights',
      status: 'In Progress',
    },
  ]);

  const handleStatusChange = (id, newStatus) => {
    const updatedPickups = pickups.map(p =>
      p.id === id ? { ...p, status: newStatus } : p
    );
    setPickups(updatedPickups);
    // Later, make API call to update status in backend
  };

  return (
    <div>
      <h4 className="text-success mb-4">Update Pickup Status</h4>
      <Table bordered hover>
        <thead>
          <tr>
            <th>Item</th>
            <th>Quantity</th>
            <th>Pickup Address</th>
            <th>Current Status</th>
            <th>Update</th>
          </tr>
        </thead>
        <tbody>
          {pickups.map(pickup => (
            <tr key={pickup.id}>
              <td>{pickup.item}</td>
              <td>{pickup.quantity}</td>
              <td>{pickup.address}</td>
              <td>{pickup.status}</td>
              <td>
                <Form.Select
                  value={pickup.status}
                  onChange={(e) => handleStatusChange(pickup.id, e.target.value)}
                >
                  <option>Pending</option>
                  <option>In Progress</option>
                  <option>Completed</option>
                </Form.Select>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
}

export default UpdateStatus;
