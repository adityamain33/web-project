import React, { useEffect, useState } from 'react';
import axios from 'axios';

const UpdateMaintenance = () => {
  const [technicianId, setTechnicianId] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [alert, setAlert] = useState({ show: false, message: '', type: '' });

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        setTechnicianId(payload.id);
      } catch (err) {
        setError('Invalid token');
      }
    } else {
      setError('Technician not logged in');
    }
  }, []);

  const fetchTasks = async () => {
    if (!technicianId) return;
    setLoading(true);
    setError('');
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`http://localhost:5000/api/technician/scheduled/${technicianId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTasks(res.data);
    } catch (err) {
      if (err.response && err.response.status === 401) {
        setError('Session expired. Please login again.');
      } else if (err.response && err.response.status === 404) {
        setError('Technician not found or not authorized');
      } else {
        setError('Failed to fetch maintenance tasks.');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (technicianId) fetchTasks();
  }, [technicianId]);

  const handleChange = (index, field, value) => {
    const updatedTasks = [...tasks];
    updatedTasks[index][field] = value;
    setTasks(updatedTasks);
  };

  const handleUpdate = async (taskId, index) => {
    try {
      const { status, technicianRemark } = tasks[index];
      const token = localStorage.getItem('token');
      await axios.patch(
        `http://localhost:5000/api/technician/update-maintenance/${taskId}`,
        { status, technicianRemark },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // Clear only remark after update success
      const updatedTasks = [...tasks];
      updatedTasks[index].technicianRemark = '';
      setTasks(updatedTasks);

      // Show bootstrap alert on success
      setAlert({ show: true, message: 'Updated successfully', type: 'success' });
      // Hide alert automatically after 3 seconds
      setTimeout(() => setAlert({ show: false, message: '', type: '' }), 3000);
    } catch {
      setAlert({ show: true, message: 'Update failed', type: 'danger' });
      setTimeout(() => setAlert({ show: false, message: '', type: '' }), 3000);
    }
  };

  return (
    <div className="container mt-4">
      <h3>Update Maintenance Tasks</h3>

      {/* Bootstrap Alert */}
      {alert.show && (
        <div className={`alert alert-${alert.type} alert-dismissible fade show`} role="alert">
          {alert.message}
          <button
            type="button"
            className="btn-close"
            aria-label="Close"
            onClick={() => setAlert({ show: false, message: '', type: '' })}
          ></button>
        </div>
      )}

      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p className="text-danger">{error}</p>
      ) : tasks.length === 0 ? (
        <p>No tasks assigned.</p>
      ) : (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Device</th>
              <th>User</th>
              <th>Status</th>
              <th>Remark</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task, idx) => (
              <tr key={task._id}>
                <td>{task.assetId?.deviceName} ({task.assetId?.category})</td>
                <td>{task.userId?.name}</td>
                <td>
                  <select
                    value={task.status}
                    onChange={(e) => handleChange(idx, 'status', e.target.value)}
                  >
                    <option value="Scheduled">Scheduled</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                    <option value="Pending">Pending</option>
                  </select>
                </td>
                <td>
                  <input
                    type="text"
                    value={task.technicianRemark || ''}
                    onChange={(e) => handleChange(idx, 'technicianRemark', e.target.value)}
                  />
                </td>
                <td>
                  <button className="btn btn-primary" onClick={() => handleUpdate(task._id, idx)}>
                    Update
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default UpdateMaintenance;
