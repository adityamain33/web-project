import React, { useEffect, useState } from 'react';
import { FaTasks, FaCheckCircle, FaHourglassHalf } from 'react-icons/fa';
import axios from 'axios';

const TechnicianDashboard = () => {
  const [dashboardData, setDashboardData] = useState({
    assignedTasks: 0,
    completedTasks: 0,
    pendingMaintenance: 0,
    upcomingTasks: []
  });

  const technicianId = localStorage.getItem('technicianId'); // Or get from context/auth

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const res = await axios.get(`/api/technician/dashboard/${technicianId}`);
        setDashboardData(res.data);
      } catch (err) {
        console.error('Failed to fetch technician dashboard data:', err);
      }
    };

    fetchDashboardData();
  }, [technicianId]);

  return (
    <div style={{ minHeight: '80vh', padding: '2rem', backgroundColor: '#f5f8fa' }}>
      <h4 className="mb-5 fw-bold" style={{ color: '#2c3e50' }}>
        📊 Technician Dashboard Overview
      </h4>

      <div className="row g-4">
        <DashboardCard
          icon={<FaTasks size={36} style={{ color: '#0277bd' }} />}
          title="Assigned Tasks"
          value={dashboardData.assignedTasks}
          bgColor="#e1f5fe"
          textColor="#01579b"
        />
        <DashboardCard
          icon={<FaCheckCircle size={36} style={{ color: '#558b2f' }} />}
          title="Completed Tasks"
          value={dashboardData.completedTasks}
          bgColor="#dcedc8"
          textColor="#33691e"
        />
        <DashboardCard
          icon={<FaHourglassHalf size={36} style={{ color: '#fbc02d' }} />}
          title="Pending Maintenance"
          value={dashboardData.pendingMaintenance}
          bgColor="#fff9c4"
          textColor="#f9a825"
        />
      </div>

      {/* Upcoming Tasks */}
      <div className="mt-5">
        <h5 style={{ color: '#607d8b', fontWeight: '600' }}>📅 Upcoming Tasks:</h5>
        <ul className="list-group mt-3" style={{ borderRadius: '8px', overflow: 'hidden' }}>
          {dashboardData.upcomingTasks.length > 0 ? (
            dashboardData.upcomingTasks.map((task, index) => (
              <li
                key={index}
                className="list-group-item d-flex justify-content-between align-items-center"
                style={{
                  backgroundColor: '#ffffff',
                  border: 'none',
                  boxShadow: '0 1px 5px rgba(0,0,0,0.1)',
                  marginTop: index > 0 ? '0.5rem' : 0
                }}
              >
                {task.task}
                <span
                  className="badge rounded-pill"
                  style={{
                    backgroundColor: index % 2 === 0 ? '#4caf50' : '#ffb300',
                    color: index % 2 === 0 ? 'white' : '#3e2723'
                  }}
                >
                  {task.due}
                </span>
              </li>
            ))
          ) : (
            <li className="list-group-item text-muted">No upcoming tasks</li>
          )}
        </ul>
      </div>
    </div>
  );
};

// Reusable card component
const DashboardCard = ({ icon, title, value, bgColor, textColor }) => (
  <div className="col-md-4">
    <div className="card shadow-sm" style={{ backgroundColor: bgColor, borderRadius: '12px', border: 'none' }}>
      <div className="card-body d-flex align-items-center gap-4">
        {icon}
        <div>
          <h6 className="mb-2" style={{ color: textColor, fontWeight: '600' }}>{title}</h6>
          <h3 className="fw-bold" style={{ color: '#2c3e50' }}>{value}</h3>
        </div>
      </div>
    </div>
  </div>
);

export default TechnicianDashboard;
