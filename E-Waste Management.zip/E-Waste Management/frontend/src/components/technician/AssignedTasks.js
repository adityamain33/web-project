import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AssignedTasks = () => {
  const [user, setUser] = useState(null);
  const [assets, setAssets] = useState([]);
  const [showMaintenanceModal, setShowMaintenanceModal] = useState(false);
  const [selectedAssetId, setSelectedAssetId] = useState(null);
  const [maintenanceDate, setMaintenanceDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [maintenanceNotes, setMaintenanceNotes] = useState('');

  const token = localStorage.getItem('token');
  const technicianId = JSON.parse(localStorage.getItem('user'))?.id;

  useEffect(() => {
    const fetchAssignedAssets = async () => {
      if (!technicianId) return;

      try {
        const res = await axios.get(
          `http://localhost:5000/api/technician/assigned-tasks/${technicianId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        setUser(res.data.user);
        setAssets(res.data.assets);
      } catch (err) {
        console.error('Error fetching assets:', err.response?.data || err.message);
        setUser(null);
        setAssets([]);
      }
    };

    fetchAssignedAssets();
  }, [technicianId, token]);

  const handleDelete = async (assetId) => {
    if (!window.confirm('Are you sure you want to delete this asset?')) return;

    try {
      await axios.delete(`http://localhost:5000/api/assets/${assetId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setAssets(prevAssets => prevAssets.filter(asset => asset._id !== assetId));
      alert('Asset deleted successfully');
    } catch (error) {
      console.error('Error deleting asset:', error.response?.data || error.message);
      alert('Failed to delete asset');
    }
  };

  const handleScheduleMaintenance = (assetId) => {
    setSelectedAssetId(assetId);
    setMaintenanceDate('');
    setTimeSlot('');
    setMaintenanceNotes('');
    setShowMaintenanceModal(true);
  };

  const handleSubmitMaintenance = async (e) => {
  e.preventDefault();
  if (!maintenanceDate || !timeSlot) {
    alert('Please select both date and time slot');
    return;
  }

  const selectedAsset = assets.find(asset => asset._id === selectedAssetId);
  if (!selectedAsset) {
    alert('Asset not found');
    return;
  }

  try {
    await axios.post(
      `http://localhost:5000/api/technician/assigned-tasks/${technicianId}/schedule-maintenance/${selectedAssetId}`,
      {
        issueDescription: maintenanceNotes,
        scheduledDate: maintenanceDate,
        scheduledTime: timeSlot,
      },
      {
        headers: { Authorization: `Bearer ${token}` }
      }
    );

    alert('Maintenance scheduled successfully');
    setShowMaintenanceModal(false);
  } catch (error) {
    console.error('Error scheduling maintenance:', error.response?.data || error.message);
    alert('Failed to schedule maintenance');
  }
};

  if (!user) return <p className="text-warning">No user assigned yet.</p>;

  return (
    <div className="p-4">
      <h4 className="mb-3">
        Assets assigned to user: <span className="text-primary">{user.name}</span>
      </h4>

      {assets.length === 0 ? (
        <p className="text-muted">No assets found for this user.</p>
      ) : (
        <table className="table table-bordered mt-3">
  <thead className="table-light">
    <tr>
      <th>Sr. No.</th>
      <th>Asset Name</th>
      <th>Category</th>
      <th>Brand</th>
      <th>Condition</th>
      <th>Warranty</th>
      <th>Purchase Year</th>
      <th>Quantity</th>
      <th>Description</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    {assets.map((asset, index) => (
      <tr key={asset._id}>
        <td>{index + 1}</td>
        <td>{asset.deviceName || 'N/A'}</td>
        <td>{asset.category || 'N/A'}</td>
        <td>{asset.brand || 'N/A'}</td>
        <td>{asset.condition || 'N/A'}</td>
        <td>{asset.warrantyStatus || 'N/A'}</td>
        <td>{asset.purchaseYear || 'N/A'}</td>
        <td>{asset.quantity || 1}</td>
        <td>{asset.description || '—'}</td>
        <td>
          <button
            className="btn btn-danger btn-sm me-2"
            onClick={() => handleDelete(asset._id)}
          >
            Delete
          </button>
          <button
            className="btn btn-primary btn-sm"
            onClick={() => handleScheduleMaintenance(asset._id)}
          >
            Schedule Maintenance
          </button>
        </td>
      </tr>
    ))}
  </tbody>
</table>

      )}

      {showMaintenanceModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog">
            <div className="modal-content p-3">
              <h5>Schedule Maintenance</h5>
              <form onSubmit={handleSubmitMaintenance}>
                <div className="mb-3">
                  <label htmlFor="maintenanceDate" className="form-label">Scheduled Date</label>
                  <input
                    id="maintenanceDate"
                    type="date"
                    className="form-control"
                    value={maintenanceDate}
                    onChange={(e) => setMaintenanceDate(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="timeSlot" className="form-label">Time Slot</label>
                  <select
                    id="timeSlot"
                    className="form-select"
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                    required
                  >
                    <option value="">Select a time slot</option>
                    <option value="09:00 AM - 11:00 AM">9:00 AM – 11:00 AM</option>
                    <option value="11:00 AM - 01:00 PM">11:00 AM – 1:00 PM</option>
                    <option value="02:00 PM - 04:00 PM">2:00 PM – 4:00 PM</option>
                    <option value="04:00 PM - 06:00 PM">4:00 PM – 6:00 PM</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label htmlFor="maintenanceNotes" className="form-label">Remarks / Notes</label>
                  <textarea
                    id="maintenanceNotes"
                    className="form-control"
                    value={maintenanceNotes}
                    onChange={(e) => setMaintenanceNotes(e.target.value)}
                    rows="3"
                  />
                </div>
                <button type="submit" className="btn btn-success me-2">Submit</button>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowMaintenanceModal(false)}
                >
                  Cancel
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AssignedTasks;
