import React from 'react';
import { Table } from 'react-bootstrap';

function AssignedPickups() {
  const assignedPickups = []; // Replace with real data from backend

  return (
    <div>
      <h4 className="text-success mb-4">Assigned Pickups</h4>
      {assignedPickups.length === 0 ? (
        <p>No pickups assigned yet.</p>
      ) : (
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
              <th>Pickup Address</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {assignedPickups.map((pickup, index) => (
              <tr key={index}>
                <td>{pickup.item}</td>
                <td>{pickup.quantity}</td>
                <td>{pickup.address}</td>
                <td>{pickup.status}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </div>
  );
}

export default AssignedPickups;