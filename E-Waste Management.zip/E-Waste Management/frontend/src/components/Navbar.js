// src/components/Navbar.js
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Container, Nav, Navbar as BSNavbar } from 'react-bootstrap';
import logo from '../assets/ewaste.jpg'; // 🔁 Make sure the logo image exists here

function Navbar() {
  const location = useLocation();

  // Hide navbar for admin, recycler, and user dashboards
  const hideForRoutes = ['/admin', '/recycler', '/user-dashboard'];
  const shouldHide = hideForRoutes.some(path => location.pathname.startsWith(path));
  if (shouldHide) return null;

  return (
    <BSNavbar expand="lg" className="navbar bg-success px-3 sticky-top" variant="dark">
      <Container>
        {/* 🔁 Logo + Brand Name */}
        <BSNavbar.Brand as={Link} to="/" className="d-flex align-items-center">
          <img
            src={logo}
            alt="Logo"
            width="40"
            height="40"
            className="rounded-circle me-2"
          />
          <span>E-Waste Management</span>
        </BSNavbar.Brand>

        <BSNavbar.Toggle aria-controls="basic-navbar-nav" />
        <BSNavbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            <Nav.Link as={Link} to="/">Home</Nav.Link>
            <Nav.Link as={Link} to="/awareness">Awareness</Nav.Link>
            <Nav.Link as={Link} to="/ourservices">Our Services</Nav.Link>
            <Nav.Link as={Link} to="/login">Login</Nav.Link>
          </Nav>
        </BSNavbar.Collapse>
      </Container>
    </BSNavbar>
  );
}

export default Navbar;
