import React from 'react';
import { Card } from 'react-bootstrap';
import { BarChart2 } from 'lucide-react';

const ChartPlaceholder = () => {
  return (
    <Card className="shadow-sm mb-4">
      <Card.Body>
        <Card.Title className="d-flex align-items-center">
          <BarChart2 className="me-2 text-success" size={20} /> Pickup Trend (Chart Coming Soon)
        </Card.Title>
        <div style={{
          height: '200px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#888',
          fontStyle: 'italic'
        }}>
          Chart Placeholder
        </div>
      </Card.Body>
    </Card>
  );
};

export default ChartPlaceholder;