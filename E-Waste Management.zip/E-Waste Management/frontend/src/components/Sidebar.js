import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Nav } from 'react-bootstrap';

const Sidebar = ({ role }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/');
  };

  const commonLinks = (
    <>
      <Nav.Link as={Link} to="/">Home</Nav.Link>
      <Nav.Link as={Link} to="/awareness">Awareness</Nav.Link>
    </>
  );

  return (
    <div className="d-flex" style={{ height: '100vh' }}>
      <div className="bg-success text-white p-3" style={{ width: '250px' }}>
        <h4 className="mb-4">E-Waste</h4>
        <Nav className="flex-column">
          {commonLinks}
          {role === 'admin' && (
            <>
              <Nav.Link as={Link} to="/inventory">Inventory</Nav.Link>
              <Nav.Link as={Link} to="/admin">Admin Dashboard</Nav.Link>
            </>
          )}
          {role === 'recycler' && (
            <Nav.Link as={Link} to="/recycler">Recycler Dashboard</Nav.Link>
          )}
          {role === 'user' && (
            <Nav.Link as={Link} to="/user">User Profile</Nav.Link>
          )}
          <Nav.Link onClick={handleLogout} className="mt-4 text-white">Logout</Nav.Link>
        </Nav>
      </div>
      <div className="flex-grow-1 bg-light p-4" style={{ overflowY: 'auto' }}>
        {/* Page content will be rendered here */}
      </div>
    </div>
  );
};

export default Sidebar;
