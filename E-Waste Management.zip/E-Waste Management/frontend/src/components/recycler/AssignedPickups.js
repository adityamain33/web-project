// components/recycler/AssignedPickups.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const statusOptions = [
  { status: 'Pending', phase: null, remark: 'Awaiting recycler assignment' },
  { status: 'Scheduled', phase: 'Assigned to recycler', remark: 'Pickup scheduled on selected date and time' },
  { status: 'In Progress', phase: 'Out for pickup / Inspection', remark: 'Recycler is en route or inspecting item' },
  { status: 'Collected', phase: null, remark: 'Item successfully collected from user' },
  { status: 'Recycled', phase: 'Functional parts extracted', remark: 'Device dismantled for material recovery' },
  { status: 'Disposed', phase: 'Non-recyclable safely disposed', remark: 'Hazardous or unusable parts disposed via certified process' },
  { status: 'Resale Initiated', phase: 'Good condition device', remark: 'Item under refurbishing or listed for resale' },
  { status: 'Completed', phase: 'Final confirmation', remark: 'Full pickup and processing lifecycle completed' },
  { status: 'Rejected', phase: 'Not eligible for recycling', remark: 'Item doesn’t meet criteria' },
];

const AssignedPickups = () => {
  const [pickups, setPickups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAssignedPickups = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (!token) throw new Error('No auth token, please login.');

      const res = await axios.get('http://localhost:5000/api/recycler/pickups/assigned', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.data && Array.isArray(res.data)) {
        setPickups(res.data);
      } else {
        setError('Invalid data format received.');
      }
    } catch (err) {
      console.error('Error fetching assigned pickups:', err);
      setError(err.message || 'Failed to load assigned pickups');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAssignedPickups();
  }, []);

  const handleStatusChange = async (pickupId, newStatus) => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('token');
      if (!token) throw new Error('No auth token, please login.');

      // Find phase & remark for the new status
      const statusObj = statusOptions.find((s) => s.status === newStatus);

      await axios.put(
        `http://localhost:5000/api/recycler/pickups/update-status/${pickupId}`,
        {
          status: newStatus,
          phase: statusObj?.phase || null,
          remark: statusObj?.remark || null,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      alert('Status updated successfully!');
      fetchAssignedPickups();
    } catch (err) {
      console.error('Error updating status:', err);
      setError(err.message || 'Failed to update status');
      setLoading(false);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-success">📦 Assigned Pickups</h2>

      {loading && <div className="text-center mt-4">Loading...</div>}

      {error && <div className="alert alert-danger">{error}</div>}

      {!loading && !error && (
        <div className="table-responsive mt-3">
          <table className="table table-hover table-striped shadow">
            <thead className="table-success">
              <tr>
                <th>#</th>
                <th>User</th>
                <th>Item</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Address</th>
                <th>Date</th>
                <th>Time Slot</th>
                <th>Status</th>
                <th>Phase</th>
                <th>Remark</th>
                <th>Update Status</th>
              </tr>
            </thead>
            <tbody>
              {pickups.length === 0 ? (
                <tr>
                  <td colSpan="12" className="text-center">No pickups assigned</td>
                </tr>
              ) : (
                pickups.map((pickup, index) => {
                  const statusObj = statusOptions.find((s) => s.status === pickup.status) || {};
                  return (
                    <tr key={pickup._id}>
                      <td>{index + 1}</td>
                      <td>{pickup.userId?.name || 'N/A'}</td>
                      <td>{pickup.itemName}</td>
                      <td>{pickup.category}</td>
                      <td>{pickup.quantity}</td>
                      <td>{pickup.address}</td>
                      <td>{new Date(pickup.preferredDate).toLocaleDateString()}</td>
                      <td>{pickup.timeSlot}</td>
                      <td>
                        <span className="badge bg-secondary">{pickup.status}</span>
                      </td>
                      <td>{statusObj.phase || '-'}</td>
                      <td>{statusObj.remark || '-'}</td>
                      <td>
                        <select
                          className="form-select"
                          value={pickup.status}
                          onChange={(e) => handleStatusChange(pickup._id, e.target.value)}
                          disabled={loading}
                        >
                          {statusOptions.map(({ status }) => (
                            <option key={status} value={status}>
                              {status}
                            </option>
                          ))}
                        </select>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AssignedPickups;
