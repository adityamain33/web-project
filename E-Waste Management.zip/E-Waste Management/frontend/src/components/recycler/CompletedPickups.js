import React, { useEffect, useState } from 'react';
import axios from 'axios';

const CompletedPickups = () => {
  const [pickups, setPickups] = useState([]);

  useEffect(() => {
    const fetchCompletedPickups = async () => {
      try {
        const token = localStorage.getItem('token');
        console.log('Fetching completed pickups with token:', token); // Debug line
        const res = await axios.get('http://localhost:5000/api/recycler/pickups/completed-pickups', {
          headers: { Authorization: `Bearer ${token}` }
        });
        console.log('Fetched pickups:', res.data); // Debug line
        setPickups(res.data);
      } catch (err) {
        console.error('Error fetching completed pickups:', err);
      }
    };
    
    fetchCompletedPickups();
  }, []);

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-success">Completed Pickups</h2>
      {pickups.length === 0 ? (
        <p>No completed pickups found.</p>
      ) : (
        <div className="table-responsive">
          <table className="table table-bordered table-striped">
            <thead className="table-success">
              <tr>
                <th>Item</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Address</th>
                <th>User</th>
                <th>Completed On</th>
              </tr>
            </thead>
            <tbody>
              {pickups.map((pickup) => (
                <tr key={pickup._id}>
                  <td>{pickup.itemName}</td>
                  <td>{pickup.category}</td>
                  <td>{pickup.quantity}</td>
                  <td>{pickup.address}</td>
                  <td>{pickup.userId ? pickup.userId.name : 'N/A'}</td>
                  <td>{new Date(pickup.updatedAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default CompletedPickups;
