import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';

const MySubscription = () => {
  const [subscription, setSubscription] = useState(null);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const res = await axios.get('/api/subscription/my-subscription', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setSubscription(res.data.subscription);
        setPlans(res.data.plans || []);
      } catch (err) {
        console.error('Fetch error:', err);
        setError('Failed to load subscription data.');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [token]);

  const handleSubscribe = async (plan) => {
    if (subscription) {
      alert('You are already subscribed.');
      return;
    }
    try {
      const res = await axios.post(
        '/api/subscription/subscribe',
        { planId: plan.id },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setSubscription(res.data.subscription);
      alert('Subscription successful!');
    } catch (err) {
      console.error('Subscribe error:', err);
      const msg = err.response?.data?.message || 'Subscription failed. Try again.';
      alert(msg);
    }
  };

  if (loading) return <p>Loading subscriptions...</p>;
  if (error) return <p className="text-danger">{error}</p>;

  return (
    <div className="container mt-4">
      {subscription ? (
        <div className="card border-success shadow-sm">
          <div className="card-header bg-success text-white fw-semibold">
            📦 Your Active Subscription
          </div>
          <div className="card-body py-3 px-4">
            <p className="mb-2">
              <strong>Plan:</strong> {subscription.planName}
            </p>
            <p className="mb-2">
              <strong>Credits:</strong> {subscription.credits}
            </p>
            <p className="mb-0">
              <strong>Valid Till:</strong>{' '}
              {new Date(subscription.expiryDate).toLocaleDateString()}
            </p>
          </div>
        </div>
      ) : (
        <>
          <h3 className="mb-4">🛒 Choose a Subscription Plan</h3>
          <PayPalScriptProvider
            options={{
              'client-id': process.env.REACT_APP_PAYPAL_CLIENT_ID,
              currency: 'USD',
            }}
          >
            <div className="row">
              {plans.map((plan) => (
                <div key={plan.id} className="col-md-4 mb-4">
                  <div className="card h-100 shadow-sm border">
                    <div className="card-body d-flex flex-column">
                      <h5 className="text-success">{plan.name}</h5>
                      <p className="mb-1">Price: ${plan.amount}</p>
                      <p className="mb-3">{plan.credits} Pickup Credit(s)</p>

                      {plan.amount === 0 ? (
                        <button
                          className="btn btn-success mt-auto"
                          onClick={() => handleSubscribe(plan)}
                        >
                          Get Free Plan
                        </button>
                      ) : (
                        <PayPalButtons
                          style={{
                            layout: 'horizontal',
                            color: 'silver',
                            shape: 'rect',
                            label: 'pay',
                            height: 40,
                          }}
                          createOrder={(data, actions) =>
                            actions.order.create({
                              purchase_units: [
                                { amount: { value: plan.amount.toString() } },
                              ],
                            })
                          }
                          onApprove={async (data, actions) => {
                            try {
                              await actions.order.capture();
                              await handleSubscribe(plan);
                            } catch (err) {
                              console.error('PayPal capture error:', err);
                              alert('Payment captured, but subscription failed.');
                            }
                          }}
                          onError={(err) => {
                            console.error('PayPal error:', err);
                            alert('Payment failed. Try again.');
                          }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </PayPalScriptProvider>
        </>
      )}
    </div>
  );
};

export default MySubscription;
