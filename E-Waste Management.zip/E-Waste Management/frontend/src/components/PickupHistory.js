import React, { useEffect, useState } from 'react';
import {
  Container,
  Table,
  Spinner,
  Alert,
  Badge,
  OverlayTrigger,
  Tooltip,
  Form,
  Row,
  Col,
  Button,
} from 'react-bootstrap';
import axios from 'axios';

// Status mapping
const statusOptions = [
  { status: 'Pending', phase: null, remark: 'Awaiting recycler assignment', color: 'warning' },
  { status: 'Scheduled', phase: 'Assigned to recycler', remark: 'Pickup scheduled on selected date and time', color: 'primary' },
  { status: 'In Progress', phase: 'Out for pickup / Inspection', remark: 'Recycler is en route or inspecting item', color: 'info' },
  { status: 'Collected', phase: null, remark: 'Item successfully collected from user', color: 'secondary' },
  { status: 'Recycled', phase: 'Functional parts extracted', remark: 'Device dismantled for material recovery', color: 'success' },
  { status: 'Disposed', phase: 'Non-recyclable safely disposed', remark: 'Hazardous or unusable parts disposed via certified process', color: 'dark' },
  { status: 'Resale Initiated', phase: 'Good condition device', remark: 'Item under refurbishing or listed for resale', color: 'success' },
  { status: 'Completed', phase: 'Final confirmation', remark: 'Full pickup and processing lifecycle completed', color: 'success' },
  { status: 'Rejected', phase: 'Not eligible for recycling', remark: 'Item doesn’t meet criteria', color: 'danger' },
];

const PickupHistory = () => {
  const [history, setHistory] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [availableMonths, setAvailableMonths] = useState([]);

  useEffect(() => {
    const fetchHistory = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        setError('No token found, please login.');
        setLoading(false);
        return;
      }

      try {
        const res = await axios.get('http://localhost:5000/api/pickups', {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (res.data.success) {
          const data = res.data.data;
          setHistory(data);
          setFiltered(data);

          const months = data.map(item => {
            const date = new Date(item.createdAt);
            return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
          });
          setAvailableMonths([...new Set(months)]);
        } else {
          setError(res.data.message || 'Failed to fetch pickup history.');
        }
      } catch (err) {
        setError('Error while fetching pickup history.');
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, []);

  useEffect(() => {
    let data = [...history];

    if (searchTerm) {
      data = data.filter(item =>
        item.itemName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.status?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (monthFilter) {
      data = data.filter(item => {
        const date = new Date(item.createdAt);
        const formatted = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        return formatted === monthFilter;
      });
    }

    setFiltered(data);
  }, [searchTerm, monthFilter, history]);

  const handleEdit = (pickup) => {
    alert(`Edit request: ${pickup.itemName}`);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this pickup request?')) return;

    try {
      const token = localStorage.getItem('token');
      const res = await axios.delete(`http://localhost:5000/api/pickups/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.data.success) {
        setHistory((prev) => prev.filter((item) => item._id !== id));
      } else {
        alert('Failed to delete request.');
      }
    } catch (err) {
      alert('Failed to delete request.');
    }
  };

  if (loading) return <Spinner animation="border" className="d-block mx-auto mt-5" />;

  return (
    <Container className="py-5">
      <h3 className="text-success mb-4">Pickup Request History</h3>
      {error && <Alert variant="danger">{error}</Alert>}

      {/* Filters */}
      <Row className="mb-4">
        <Col md={6}>
          <Form.Control
            type="text"
            placeholder="Search by item, category, status..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </Col>
        <Col md={4}>
          <Form.Select value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)}>
            <option value="">Filter by Month</option>
            {availableMonths.map(month => (
              <option key={month} value={month}>
                {new Date(month + "-01").toLocaleString('default', { month: 'long', year: 'numeric' })}
              </option>
            ))}
          </Form.Select>
        </Col>
        <Col md={2}>
          <Button variant="secondary" onClick={() => { setSearchTerm(''); setMonthFilter(''); }}>
            Clear Filters
          </Button>
        </Col>
      </Row>

      <Table striped bordered hover responsive className="align-middle text-center">
        <thead className="table-success">
          <tr>
            <th>#</th>
            <th>Item</th>
            <th>Category</th>
            <th>Qty</th>
            <th>Address</th>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
            <th>Remark</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {filtered.length === 0 ? (
            <tr><td colSpan="10">No records found.</td></tr>
          ) : (
            filtered.map((pickup, index) => {
              const status = statusOptions.find(s => s.status === pickup.status) || {};
              return (
                <tr key={pickup._id}>
                  <td>{index + 1}</td>
                  <td>{pickup.itemName}</td>
                  <td>{pickup.category}</td>
                  <td>{pickup.quantity}</td>
                  <td>{pickup.pickupAddress}</td>
                  <td>{pickup.preferredDate?.split('T')[0]}</td>
                  <td>{pickup.timeSlot}</td>
                  <td>
                    <OverlayTrigger
                      overlay={<Tooltip>{status.phase || pickup.status}</Tooltip>}
                    >
                      <Badge bg={status.color || 'secondary'}>{pickup.status}</Badge>
                    </OverlayTrigger>
                  </td>
                  <td>{status.remark}</td>
                  <td>
                    <Button size="sm" variant="outline-primary" onClick={() => handleEdit(pickup)}>Edit</Button>{' '}
                    <Button size="sm" variant="outline-danger" onClick={() => handleDelete(pickup._id)}>Delete</Button>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </Table>
    </Container>
  );
};

export default PickupHistory;
