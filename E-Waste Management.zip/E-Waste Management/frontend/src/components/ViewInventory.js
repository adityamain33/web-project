import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Modal, Button, Form } from 'react-bootstrap';

function ViewInventory() {
  const [inventory, setInventory] = useState([]);
  const [editingItem, setEditingItem] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [scheduleForm, setScheduleForm] = useState({
    date: '',
    timeSlot: '',
    note: ''
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterCondition, setFilterCondition] = useState('');
  const [monthYearFilter, setMonthYearFilter] = useState('');
  const [availableMonths, setAvailableMonths] = useState([]);

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    const token = localStorage.getItem('token');
    if (!token) return alert('User not logged in');

    try {
      const res = await axios.get('http://localhost:5000/api/inventory/user', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setInventory(res.data);

      // Extract unique Month-Year options from createdAt
      const months = res.data.map(item => {
        const date = new Date(item.createdAt);
        return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;
      });
      const uniqueMonths = [...new Set(months)];
      setAvailableMonths(uniqueMonths);
    } catch (err) {
      alert('Error fetching inventory');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure to delete?')) return;
    const token = localStorage.getItem('token');
    try {
      await axios.delete(`http://localhost:5000/api/inventory/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchInventory();
    } catch (err) {
      alert('Delete failed');
    }
  };

  const handleEditOpen = (item) => {
    setEditingItem(item._id);
    setEditForm({
      deviceName: item.deviceName,
      category: item.category,
      quantity: item.quantity,
      condition: item.condition,
      description: item.description || ''
    });
  };

  const handleEditChange = (e) => {
    setEditForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleEditSubmit = async (id) => {
    const token = localStorage.getItem('token');
    try {
      await axios.put(`http://localhost:5000/api/inventory/${id}`, editForm, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setEditingItem(null);
      fetchInventory();
    } catch (err) {
      alert('Update failed');
    }
  };

  const openScheduleModal = (item) => {
    setSelectedItem(item);
    setShowModal(true);
    setScheduleForm({ date: '', timeSlot: '', note: '' });
  };

  const handleScheduleChange = (e) => {
    const { name, value } = e.target;
    setScheduleForm(prev => ({ ...prev, [name]: value }));
  };

  const handleScheduleSubmit = async () => {
    const token = localStorage.getItem('token');
    if (!token || !selectedItem) return;

    try {
      await axios.post('http://localhost:5000/api/maintenance/schedule', {
        inventoryId: selectedItem._id,
        deviceName: selectedItem.deviceName,
        category: selectedItem.category,
        quantity: selectedItem.quantity,
        condition: selectedItem.condition,
        description: selectedItem.description,
        ...scheduleForm
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setShowModal(false);
      alert('Maintenance scheduled successfully!');
    } catch (err) {
      alert('Failed to schedule maintenance');
    }
  };

  const timeSlots = [
    '10:00 AM - 12:00 PM',
    '12:00 PM - 2:00 PM',
    '2:00 PM - 4:00 PM',
    '4:00 PM - 6:00 PM'
  ];

  const filteredInventory = inventory.filter(item => {
    const matchesSearch = item.deviceName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory ? item.category === filterCategory : true;
    const matchesCondition = filterCondition ? item.condition === filterCondition : true;

    const itemDate = new Date(item.createdAt);
    const itemMonthYear = `${itemDate.getFullYear()}-${(itemDate.getMonth() + 1).toString().padStart(2, '0')}`;
    const matchesMonth = monthYearFilter ? itemMonthYear === monthYearFilter : true;

    return matchesSearch && matchesCategory && matchesCondition && matchesMonth;
  });

  return (
    <div className="container my-5">
      <h2 className="text-success mb-4 text-center">📦 My Electronic Assets</h2>

      <div className="row mb-3">
        <div className="col-md-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search Device"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="col-md-3">
          <select
            className="form-select"
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            <option value="Laptop">Laptop</option>
            <option value="Mobile">Mobile</option>
            <option value="TV">TV</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div className="col-md-3">
          <select
            className="form-select"
            value={filterCondition}
            onChange={(e) => setFilterCondition(e.target.value)}
          >
            <option value="">All Conditions</option>
            <option value="Working">Working</option>
            <option value="Damaged">Damaged</option>
            <option value="Not Working">Not Working</option>
          </select>
        </div>
        <div className="col-md-3">
          <select
            className="form-select"
            value={monthYearFilter}
            onChange={(e) => setMonthYearFilter(e.target.value)}
          >
            <option value="">All Dates</option>
            {availableMonths.map(month => {
              const [year, m] = month.split("-");
              const date = new Date(`${year}-${m}-01`);
              const label = date.toLocaleString('default', { month: 'long', year: 'numeric' });
              return <option key={month} value={month}>{label}</option>;
            })}
          </select>
        </div>
      </div>

      <div className="table-responsive">
        <table className="table table-bordered text-center">
          <thead className="table-success">
            <tr>
              <th>Device</th>
              <th>Category</th>
              <th>Quantity</th>
              <th>Condition</th>
              <th>Description</th>
              <th>Created At</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredInventory.map(item => (
              <tr key={item._id}>
                <td>
                  {editingItem === item._id ? (
                    <input
                      name="deviceName"
                      value={editForm.deviceName}
                      onChange={handleEditChange}
                    />
                  ) : (
                    item.deviceName
                  )}
                </td>
                <td>
                  {editingItem === item._id ? (
                    <input
                      name="category"
                      value={editForm.category}
                      onChange={handleEditChange}
                    />
                  ) : (
                    item.category
                  )}
                </td>
                <td>
                  {editingItem === item._id ? (
                    <input
                      name="quantity"
                      value={editForm.quantity}
                      onChange={handleEditChange}
                    />
                  ) : (
                    item.quantity
                  )}
                </td>
                <td>
                  {editingItem === item._id ? (
                    <select
                      name="condition"
                      value={editForm.condition}
                      onChange={handleEditChange}
                    >
                      <option value="Working">Working</option>
                      <option value="Damaged">Damaged</option>
                      <option value="Not Working">Not Working</option>
                    </select>
                  ) : (
                    item.condition
                  )}
                </td>
                <td>
                  {editingItem === item._id ? (
                    <input
                      name="description"
                      value={editForm.description}
                      onChange={handleEditChange}
                    />
                  ) : (
                    item.description || '-'
                  )}
                </td>
                <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                <td>
                  {editingItem === item._id ? (
                    <>
                      <button className="btn btn-success btn-sm me-2" onClick={() => handleEditSubmit(item._id)}>Save</button>
                      <button className="btn btn-secondary btn-sm" onClick={() => setEditingItem(null)}>Cancel</button>
                    </>
                  ) : (
                    <>
                      <button className="btn btn-primary btn-sm me-2" onClick={() => handleEditOpen(item)}>Edit</button>
                      <button className="btn btn-danger btn-sm me-2" onClick={() => handleDelete(item._id)}>Delete</button>
                      {/* <button className="btn btn-warning btn-sm" onClick={() => openScheduleModal(item)}>Schedule</button> */}
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredInventory.length === 0 && <p className="text-center text-muted">No records found</p>}
      </div>

      {/* Schedule Modal */}
      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Schedule Maintenance</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Date</Form.Label>
              <Form.Control
                type="date"
                name="date"
                value={scheduleForm.date}
                onChange={handleScheduleChange}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Time Slot</Form.Label>
              <Form.Select
                name="timeSlot"
                value={scheduleForm.timeSlot}
                onChange={handleScheduleChange}
              >
                <option value="">Select</option>
                {timeSlots.map(slot => (
                  <option key={slot} value={slot}>{slot}</option>
                ))}
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Additional Note</Form.Label>
              <Form.Control
                as="textarea"
                name="note"
                value={scheduleForm.note}
                onChange={handleScheduleChange}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>Cancel</Button>
          <Button variant="success" onClick={handleScheduleSubmit}>Schedule</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default ViewInventory;
