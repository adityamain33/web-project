// src/components/RequestPickupForm.js
import React, { useState, useEffect } from 'react';
import { Form, Button, Card, Row, Col, Alert } from 'react-bootstrap';
import axios from 'axios';

const alertStyle = {
  position: 'fixed',
  top: '20px',
  right: '20px',
  zIndex: 1050,
  minWidth: '300px',
  boxShadow: '0 4px 8px rgba(0,0,0,0.2)',
};

const RequestPickupForm = () => {
  const [formData, setFormData] = useState({
    itemName: '',
    category: '',
    quantity: '',
    address: '',
    preferredDate: '',
    timeSlot: '',
    notes: '',
    deviceCondition: '',
    expectedValue: '',
    willingToSell: '',
    itemImage: '',
  });
  const [alert, setAlert] = useState({ message: '', variant: '', show: false });
  const [userCredits, setUserCredits] = useState(0);
  const token = localStorage.getItem('token');

  // fetch remaining credits
  useEffect(() => {
    (async () => {
      try {
        const res = await axios.get('/api/subscription/my-subscription', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setUserCredits(res.data.subscription?.credits || 0);
      } catch (err) {
        console.error('Error fetching credits:', err);
      }
    })();
  }, [token]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'itemImage') {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () =>
        setFormData((prev) => ({ ...prev, itemImage: reader.result }));
      if (file) reader.readAsDataURL(file);
      return;
    }
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (userCredits <= 0) {
      setAlert({ message: 'No credits left, please subscribe first.', variant: 'danger', show: true });
      return;
    }
    try {
      const res = await axios.post(
        '/api/pickups',
        formData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setAlert({ message: res.data.message || 'Pickup requested!', variant: 'success', show: true });
      // optionally clear form or decrement local credit count:
      setUserCredits((c) => c - 1);
    } catch (err) {
      const msg = err.response?.data?.message || 'Request failed. Try again.';
      setAlert({ message: msg, variant: 'danger', show: true });
    }
  };

  const handleAlertClose = () => setAlert((prev) => ({ ...prev, show: false }));

  return (
    <>
      {alert.show && (
        <Alert
          variant={alert.variant}
          onClose={handleAlertClose}
          dismissible
          style={alertStyle}
        >
          {alert.message}
        </Alert>
      )}

      <Card className="p-4 shadow-sm">
        <h4 className="mb-4">Request E-Waste Pickup</h4>

        <Form onSubmit={handleSubmit}>
          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Item Name</Form.Label>
              <Form.Control
                type="text" name="itemName" value={formData.itemName}
                onChange={handleChange} required
              />
            </Col>
            <Col md={6}>
              <Form.Label>Category</Form.Label>
              <Form.Select
                name="category" value={formData.category}
                onChange={handleChange} required
              >
                <option value="">Select</option>
                <option>Mobile</option>
                <option>Laptop</option>
                <option>Appliance</option>
              </Form.Select>
            </Col>
          </Row>

          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Quantity</Form.Label>
              <Form.Control
                type="number" name="quantity" value={formData.quantity}
                onChange={handleChange} required
              />
            </Col>
            <Col md={6}>
              <Form.Label>Address</Form.Label>
              <Form.Control
                type="text" name="address" value={formData.address}
                onChange={handleChange} required
              />
            </Col>
          </Row>

          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Preferred Date</Form.Label>
              <Form.Control
                type="date" name="preferredDate" value={formData.preferredDate}
                onChange={handleChange} required
              />
            </Col>
            <Col md={6}>
              <Form.Label>Time Slot</Form.Label>
              <Form.Select
                name="timeSlot" value={formData.timeSlot}
                onChange={handleChange} required
              >
                <option value="">Select</option>
                <option>10am - 12pm</option>
                <option>12pm - 2pm</option>
                <option>2pm - 4pm</option>
              </Form.Select>
            </Col>
          </Row>

          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Additional Notes</Form.Label>
              <Form.Control
                as="textarea" rows={3} name="notes"
                value={formData.notes} onChange={handleChange}
              />
            </Col>
            <Col md={6}>
              <Form.Label>Device Condition</Form.Label>
              <Form.Select
                name="deviceCondition" value={formData.deviceCondition}
                onChange={handleChange} required
              >
                <option value="">Select</option>
                <option>Dead</option>
                <option>Repairable</option>
                <option>Working</option>
              </Form.Select>
            </Col>
          </Row>

          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Expected Value</Form.Label>
              <Form.Control
                type="number" name="expectedValue"
                value={formData.expectedValue}
                onChange={handleChange}
              />
            </Col>
            <Col md={6}>
              <Form.Label>Willing to Sell?</Form.Label>
              <Form.Select
                name="willingToSell" value={formData.willingToSell}
                onChange={handleChange} required
              >
                <option value="">Select</option>
                <option>Yes</option>
                <option>No</option>
              </Form.Select>
            </Col>
          </Row>

          <Row className="mb-3">
            <Col>
              <Form.Label>Upload Device Photo</Form.Label>
              <Form.Control
                type="file" name="itemImage" accept="image/*"
                onChange={handleChange}
              />
              {formData.itemImage && (
                <img
                  src={formData.itemImage}
                  alt="Preview"
                  className="mt-2"
                  style={{ maxHeight: '120px' }}
                />
              )}
            </Col>
          </Row>

          <Button
            variant="primary"
            type="submit"
            disabled={userCredits <= 0}
          >
            Request Pickup
          </Button>
        </Form>
      </Card>
    </>
  );
};

export default RequestPickupForm;
