// src/components/CompletedPickups.js
import React from 'react';
import { Table } from 'react-bootstrap';

function CompletedPickups() {
  const completedPickups = [
    {
      item: 'Old Laptop',
      quantity: 2,
      address: '123 Green Street',
      completedAt: '2025-04-09',
    },
    {
      item: 'Broken Phone',
      quantity: 1,
      address: '456 Eco Avenue',
      completedAt: '2025-04-08',
    },
  ]; // Replace this with dynamic data from backend later

  return (
    <div>
      <h4 className="text-success mb-4">Completed Pickups</h4>
      {completedPickups.length === 0 ? (
        <p>No pickups completed yet.</p>
      ) : (
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
              <th>Pickup Address</th>
              <th>Date Completed</th>
            </tr>
          </thead>
          <tbody>
            {completedPickups.map((pickup, index) => (
              <tr key={index}>
                <td>{pickup.item}</td>
                <td>{pickup.quantity}</td>
                <td>{pickup.address}</td>
                <td>{pickup.completedAt}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </div>
  );
}

export default CompletedPickups;
