// utils/auth.js
export const getUserId = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  return user?._id || null;
};

export const isLoggedIn = () => !!localStorage.getItem("token");

export const getUserRole = () => {
  const user = JSON.parse(localStorage.getItem("user"));
  return user?.role || null;
};

export const logout = () => {
  localStorage.clear();
};
