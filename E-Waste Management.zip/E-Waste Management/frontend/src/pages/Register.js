// ✅ Full updated Register.js with technician fields
import React, { useState } from 'react';
import { Form, Button, Container, Card, Alert, ToggleButtonGroup, ToggleButton } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';

const Register = () => {
  const [role, setRole] = useState('user');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mobile, setMobile] = useState('');
  const [organization, setOrganization] = useState('');
  const [location, setLocation] = useState('');
  const [experienceYears, setExperienceYears] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const payload = {
      name,
      email,
      password,
      role,
      mobile,
      ...(role === 'recycler' && { organization, location }),
      ...(role === 'technician' && { experienceYears, specialization, location })
    };

    try {
      const res = await fetch('http://localhost:5000/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Registration failed');

      setSuccess('Registration successful! Redirecting to login...');
      setTimeout(() => navigate('/'), 2000);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
      <Card className="p-4 shadow w-100" style={{ maxWidth: '550px' }}>
        <h2 className="mb-4 text-center text-success">Register</h2>

        {success && <Alert variant="success">{success}</Alert>}
        {error && <Alert variant="danger">{error}</Alert>}

        <div className="d-flex justify-content-center mb-3">
          <ToggleButtonGroup type="radio" name="roles" value={role} onChange={val => setRole(val)}>
            <ToggleButton id="tbg-radio-1" value="user" variant={role === 'user' ? 'success' : 'outline-success'}>
              User
            </ToggleButton>
            <ToggleButton id="tbg-radio-2" value="recycler" variant={role === 'recycler' ? 'success' : 'outline-success'}>
              Recycler
            </ToggleButton>
            <ToggleButton id="tbg-radio-3" value="technician" variant={role === 'technician' ? 'success' : 'outline-success'}>
              Technician
            </ToggleButton>
          </ToggleButtonGroup>
        </div>

        <Form onSubmit={handleRegister}>
          <Form.Group className="mb-3">
            <Form.Label>Name</Form.Label>
            <Form.Control type="text" required value={name} onChange={(e) => setName(e.target.value)} />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Email</Form.Label>
            <Form.Control type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Password</Form.Label>
            <Form.Control type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Mobile Number</Form.Label>
            <Form.Control type="text" required value={mobile} onChange={(e) => setMobile(e.target.value)} />
          </Form.Group>

          {/* Recycler Fields */}
          {role === 'recycler' && (
            <>
              <Form.Group className="mb-3">
                <Form.Label>Organization Name</Form.Label>
                <Form.Control type="text" required value={organization} onChange={(e) => setOrganization(e.target.value)} />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Location</Form.Label>
                <Form.Control type="text" required value={location} onChange={(e) => setLocation(e.target.value)} />
              </Form.Group>
            </>
          )}

          {/* Technician Fields */}
          {/* {role === 'technician' && (
            <>
              <Form.Group className="mb-3">
                <Form.Label>Years of Experience</Form.Label>
                <Form.Control type="number" required min="0" value={experienceYears} onChange={(e) => setExperienceYears(e.target.value)} />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Specialization</Form.Label>
                <Form.Control type="text" required value={specialization} onChange={(e) => setSpecialization(e.target.value)} />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Location</Form.Label>
                <Form.Control type="text" required value={location} onChange={(e) => setLocation(e.target.value)} />
              </Form.Group>
            </>
          )} */}

          <Button variant="success" type="submit" className="w-100">Register</Button>
        </Form>
        <p className="mt-3 text-center">
          Already Registered? <Link to="/login">Login</Link>
        </p>
      </Card>
    </Container>
  );
};

export default Register;
