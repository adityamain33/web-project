import React from 'react';

const services = [
  {
    icon: "🔄",
    title: "E-Waste Collection & Pickup",
    description:
      "Schedule a hassle-free pickup of your electronic waste from your doorstep, ensuring eco-friendly disposal.",
  },
  {
    icon: "♻️",
    title: "Device Recycling & Disposal",
    description:
      "We responsibly recycle electronic devices following environmental regulations to reduce harmful waste.",
  },
  {
    icon: "🔧",
    title: "Repair & Maintenance",
    description:
      "Get your devices repaired or maintained by our certified technicians to extend their life and usability.",
  },
  
];

const OurServices = () => {
  return (
    <div className="container my-5">
      <h1 className="text-center mb-4" style={{ color: '#2a7a2a' }}>
        Our Services
      </h1>
      <p className="text-center mb-5 fs-5">
        Explore the wide range of professional and eco-friendly services we offer to manage your electronic waste responsibly.
      </p>

      <div className="row g-4">
        {services.map(({ icon, title, description }, idx) => (
          <div className="col-md-6 col-lg-4" key={idx}>
            <div className="card shadow-sm h-100 border-success">
              <div
                className="card-body d-flex flex-column align-items-center text-center"
                style={{ color: '#2a7a2a' }}
              >
                <div
                  style={{
                    fontSize: '3rem',
                    backgroundColor: '#e6f4ea',
                    borderRadius: '50%',
                    width: '80px',
                    height: '80px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: '15px',
                  }}
                >
                  {icon}
                </div>
                <h5 className="card-title fw-bold">{title}</h5>
                <p className="card-text text-muted">{description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center mt-5">
        <p className="fs-6 text-secondary">
          Have questions or want to schedule a service? <a href="/contact">Contact us</a> today!
        </p>
      </div>
    </div>
  );
};

export default OurServices;
