// src/pages/Awareness.js
import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Modal } from 'react-bootstrap';

// Sample Images
import toxicMaterialsImg from '../assets/toxic-materials.jpeg';
import recyclingValueImg from '../assets/recycling-value.jpeg';
import legalComplianceImg from '../assets/legal-compliance.jpg';

const Awareness = () => {
  const [showModal, setShowModal] = useState(false);
  const [modalContent, setModalContent] = useState('');

  const handleShowModal = (content) => {
    setModalContent(content);
    setShowModal(true);
  };
  const handleCloseModal = () => setShowModal(false);

  // Shared style for image container
  const imgWrapperStyle = { height: '180px', overflow: 'hidden' };
  const imgStyle = { width: '100%', height: '100%', objectFit: 'cover' };

  return (
    <div style={{ backgroundColor: '#f0fff4', minHeight: '100vh' }}>
      <Container className="py-5">
        <h2 className="text-center mb-5 text-success display-4">
          Why E-Waste Management Matters
        </h2>
        <Row className="mb-5">
          <Col>
            <p className="lead text-center">
              E-waste management plays a crucial role in safeguarding the environment, human health, and our planet’s resources.
              Discover the impact of proper e-waste disposal and recycling through this comprehensive guide.
            </p>
          </Col>
        </Row>

        {/* Make all columns stretch to same height */}
        <Row className="g-4 align-items-stretch">
          {[
            {
              key: 'toxicMaterials',
              img: toxicMaterialsImg,
              title: 'Toxic Materials in E-Waste',
              text:
                'Electronic waste contains harmful materials such as lead, mercury, and cadmium. Improper disposal can result in hazardous contamination of our soil, water, and air, threatening ecosystems and human health.',
            },
            {
              key: 'recyclingValue',
              img: recyclingValueImg,
              title: 'The Value of Recycling',
              text:
                'Recycling e-waste helps conserve valuable resources, such as metals and plastics. By reusing components, we can reduce the need for mining and manufacturing, which conserves energy and reduces pollution.',
            },
            {
              key: 'legalCompliance',
              img: legalComplianceImg,
              title: 'Legal Compliance and E-Waste',
              text:
                'Many countries have regulations in place to govern e-waste disposal. Proper e-waste management ensures compliance with environmental laws, avoiding fines and penalties for improper disposal.',
            },
          ].map(({ key, img, title, text }) => (
            <Col md={4} key={key} className="d-flex">
              <Card className="shadow-lg flex-fill" style={{ borderRadius: '10px' }}>
                <div style={imgWrapperStyle}>
                  <Card.Img variant="top" src={img} alt={title} style={imgStyle} />
                </div>
                <Card.Body className="d-flex flex-column">
                  <Card.Title className="text-success">{title}</Card.Title>
                  <Card.Text className="flex-grow-1">{text}</Card.Text>
                  <Button
                    variant="outline-success"
                    onClick={() => handleShowModal(key)}
                    className="mt-3 align-self-start"
                  >
                    Learn More
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>

        {/* Modal */}
        <Modal show={showModal} onHide={handleCloseModal} centered>
          <Modal.Header closeButton>
            <Modal.Title className="text-success">
              {modalContent === 'toxicMaterials' && 'Toxic Materials in E-Waste'}
              {modalContent === 'recyclingValue' && 'The Value of Recycling E-Waste'}
              {modalContent === 'legalCompliance' && 'Legal Compliance in E-Waste Management'}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {modalContent === 'toxicMaterials' && (
              <>
                <p>
                  E-waste contains materials that are highly toxic when exposed to the environment. Some of the most dangerous substances include:
                </p>
                <ul>
                  <li><strong>Lead:</strong> Causes brain and kidney damage.</li>
                  <li><strong>Mercury:</strong> Leads to nerve damage.</li>
                  <li><strong>Cadmium:</strong> A carcinogen harming kidneys and bones.</li>
                </ul>
              </>
            )}
            {modalContent === 'recyclingValue' && (
              <>
                <p>
                  Recycling e-waste conserves resources and reduces environmental impact by:
                </p>
                <ul>
                  <li><strong>Recovering precious metals</strong> like gold and silver.</li>
                  <li><strong>Saving energy</strong> compared to mining new materials.</li>
                  <li><strong>Cutting pollution</strong> from manufacturing processes.</li>
                </ul>
              </>
            )}
            {modalContent === 'legalCompliance' && (
              <>
                <p>
                  Key regulations include:
                </p>
                <ul>
                  <li><strong>EU WEEE Directive:</strong> Manufacturer recycling responsibility.</li>
                  <li><strong>US RCRA:</strong> Safe disposal of hazardous materials.</li>
                  <li><strong>Extended Producer Responsibility:</strong> Lifecycle accountability for devices.</li>
                </ul>
              </>
            )}
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleCloseModal}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      </Container>
    </div>
  );
};

export default Awareness;
