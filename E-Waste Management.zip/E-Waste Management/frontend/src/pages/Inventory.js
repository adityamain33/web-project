import React from 'react';

const Inventory = () => {
  return (
    <div>
      <h2 className="mb-4">Inventory Page</h2>
      <p>This is the inventory page for managing e-waste items.</p>
      {/* Yaha baad mein inventory table ya form aa sakta hai */}
    </div>
  );
};

export default Inventory;
