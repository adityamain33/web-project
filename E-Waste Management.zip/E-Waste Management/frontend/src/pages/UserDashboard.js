import React from 'react';
import { Card } from 'react-bootstrap';

const UserDashboard = () => {
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <div>
      <h2 className="mb-4 text-success">Welcome, {user?.name || "User"} 👋</h2>
      <Card className="p-4 shadow-sm">
        <h5>This is your Dashboard</h5>
        <p>Use the sidebar to manage your assets, request pickups, and more.</p>
      </Card>
    </div>
  );
};

export default UserDashboard;
