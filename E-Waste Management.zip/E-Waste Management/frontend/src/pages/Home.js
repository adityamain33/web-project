// src/pages/Home.js
import React from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import eWasteImage from '../assets/ewaste.jpg';

const Home = () => {
  const navigate = useNavigate();

  return (
    <div style={{ backgroundColor: '#f0fff4', flex: '1' }}>
  <Container className="py-5">
    <Row className="align-items-center">
      <Col md={6} className="text-center text-md-start">
        <h1 className="display-4 text-success mb-4">E-Waste Management System</h1>
        <p className="lead mb-4">
          Join us in creating a sustainable future by responsibly managing and recycling your electronic waste. Help protect the environment.
        </p>
        <Button
          variant="success"
          size="lg"
          className="me-3"
          onClick={() => navigate('/awareness')}
          style={{
            padding: '10px 30px',
            fontSize: '18px',
            borderRadius: '25px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
          }}
        >
          Learn More
        </Button>
      </Col>
      <Col md={6} className="text-center mt-4 mt-md-0">
        <img
          src={eWasteImage}
          alt="E-Waste"
          className="img-fluid rounded-circle shadow-lg"
          style={{
            width: '320px',
            height: '320px',
            objectFit: 'contain',
            padding: '10px',
            backgroundColor: 'white',
          }}
        />
      </Col>
    </Row>
  </Container>
</div>
  );
};

export default Home;
