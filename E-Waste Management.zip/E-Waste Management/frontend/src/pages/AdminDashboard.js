import React, { useEffect, useState } from 'react';
import { Row, Col, Card } from 'react-bootstrap';
import axios from 'axios';
import {
  FaUsers, FaRecycle, FaBoxOpen, FaClipboardList,
  FaClock, FaCheckCircle, FaTools
} from 'react-icons/fa';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    users: 0,
    recyclers: 0,
    pickups: 0,
    inventory: 0,
    pendingPickups: 0,
    completedPickups: 0,
    activeMaintenances: 0,
  });

  const token = localStorage.getItem('token');

  const fetchStats = async () => {
    try {
      const headers = { Authorization: `Bearer ${token}` };

      const usersRes = await axios.get('http://localhost:5000/api/admin/users/count', { headers });
      const recyclersRes = await axios.get('http://localhost:5000/api/admin/recyclers/count', { headers });
      const pickupsRes = await axios.get('http://localhost:5000/api/admin/pickups/count', { headers });
      const inventoryRes = await axios.get('http://localhost:5000/api/inventory', { headers });
      const pendingRes = await axios.get('http://localhost:5000/api/admin/pickups/count?status=pending', { headers });
      const completedRes = await axios.get('http://localhost:5000/api/admin/pickups/count?status=completed', { headers });
      const maintenanceRes = await axios.get('http://localhost:5000/api/admin/maintenance/count?status=active', { headers });

      setStats({
        users: usersRes.data.count,
        recyclers: recyclersRes.data.count,
        pickups: pickupsRes.data.count,
        inventory: inventoryRes.data.length,
        pendingPickups: pendingRes.data.count,
        completedPickups: completedRes.data.count,
        activeMaintenances: maintenanceRes.data.count,
      });
    } catch (err) {
      console.error('Dashboard fetch error:', err?.response?.data || err.message);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const cardData = [
    { label: 'Total Users', value: stats.users, icon: <FaUsers />, color: 'success' },
    { label: 'Total Recyclers', value: stats.recyclers, icon: <FaRecycle />, color: 'info' },
    { label: 'Pickup Requests', value: stats.pickups, icon: <FaClipboardList />, color: 'primary' },
    { label: 'Inventory Count', value: stats.inventory, icon: <FaBoxOpen />, color: 'secondary' },
    { label: 'Pending Pickups', value: stats.pendingPickups, icon: <FaClock />, color: 'warning' },
    { label: 'Completed Pickups', value: stats.completedPickups, icon: <FaCheckCircle />, color: 'success' },
    { label: 'Active Maintenances', value: stats.activeMaintenances, icon: <FaTools />, color: 'danger' },
  ];

  return (
    <div className="p-4">
      <h2 className="mb-4">Admin Dashboard</h2>
      <Row>
        {cardData.map((item, index) => (
          <Col key={index} md={4} className="mb-4">
            <Card className={`border-start border-${item.color} border-5 shadow-sm h-100`}>
              <Card.Body className="d-flex align-items-center">
                <div className={`me-3 text-${item.color}`} style={{ fontSize: '2rem' }}>
                  {item.icon}
                </div>
                <div>
                  <h6 className="text-muted mb-1">{item.label}</h6>
                  <h4 className="mb-0">{item.value}</h4>
                </div>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default AdminDashboard;
