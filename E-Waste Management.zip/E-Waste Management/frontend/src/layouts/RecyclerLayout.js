import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Container, Navbar } from 'react-bootstrap';

function RecyclerLayout() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user'));

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', backgroundColor: '#f8f9fa' }}>
      {/* Sidebar */}
      <div style={{ width: '220px', backgroundColor: '#2e7d32', color: 'white', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          <h4 className="text-white px-3 pt-3">Recycler Panel</h4>
          <div className="mt-4 d-flex flex-column px-2">
            <NavLink to="/recycler/dashboard" className={({ isActive }) => isActive ? 'nav-link active text-white bg-success rounded px-3 py-2 mb-2' : 'nav-link text-white px-3 py-2 mb-2'}>Dashboard</NavLink>
            <NavLink to="/recycler/assigned-pickups" className={({ isActive }) => isActive ? 'nav-link active text-white bg-success rounded px-3 py-2 mb-2' : 'nav-link text-white px-3 py-2 mb-2'}>Assigned Pickups</NavLink>
            <NavLink to="/recycler/completed-pickups" className={({ isActive }) => isActive ? 'nav-link active text-white bg-success rounded px-3 py-2 mb-2' : 'nav-link text-white px-3 py-2 mb-2'}>
            Completed Pickups
            </NavLink>

            {/* <NavLink to="/recycler/update-status" className={({ isActive }) => isActive ? 'nav-link active text-white bg-success rounded px-3 py-2 mb-2' : 'nav-link text-white px-3 py-2 mb-2'}>
            Update Status
            </NavLink> */}

          </div>
        </div>
        <div className="p-3">
          <button className="w-100 btn btn-light text-success fw-medium rounded" onClick={handleLogout}>Logout</button>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <Navbar className="justify-content-end px-4 py-2 border-bottom bg-white">
          <Navbar.Text>
            Welcome, <span className="text-success fw-bold">{user?.name}</span>
          </Navbar.Text>
          <div className="ms-3 rounded-circle bg-success text-white fw-bold d-flex align-items-center justify-content-center" style={{ width: '35px', height: '35px' }}>
            {user?.name?.[0] || 'U'}
          </div>
        </Navbar>
        <Container fluid className="mt-4 px-4">
          <Outlet />
        </Container>
      </div>
    </div>
  );
}

export default RecyclerLayout;