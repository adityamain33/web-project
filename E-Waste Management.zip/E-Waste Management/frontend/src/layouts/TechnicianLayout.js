import React from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import { FaTasks, FaTools, FaSignOutAlt, FaTachometerAlt } from 'react-icons/fa';

const TechnicianLayout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <div className="d-flex min-vh-100" style={{ backgroundColor: '#f5f9f6' }}>
      {/* Sidebar */}
      <div
        className="d-flex flex-column p-4"
        style={{
          width: '260px',
          backgroundColor: '#27ae60', // Dark green background
          color: 'white',
          borderRight: '3px solid #1e8449',
          minHeight: '100vh',
          position: 'sticky',
          top: 0,
        }}
      >
        <h5 className="mb-5 text-center fw-bold" style={{ letterSpacing: '1.2px' }}>
          🛠️ Technician
        </h5>

        <nav className="d-flex flex-column gap-3 flex-grow-1">
          <Link
            to="/technician-dashboard"
            className="text-decoration-none d-flex align-items-center gap-3 px-3 py-2 rounded"
            style={{ color: 'white', fontWeight: '600', transition: 'background-color 0.3s' }}
            onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#1e8449')}
            onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
          >
            <FaTachometerAlt size={20} /> Dashboard
          </Link>

          <Link
            to="/technician-dashboard/assigned-tasks"
            className="text-decoration-none d-flex align-items-center gap-3 px-3 py-2 rounded"
            style={{ color: 'white', fontWeight: '600', transition: 'background-color 0.3s' }}
            onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#1e8449')}
            onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
          >
            <FaTasks size={20} /> Assigned Tasks
          </Link>

          <Link
            to="/technician-dashboard/update-maintenance"
            className="text-decoration-none d-flex align-items-center gap-3 px-3 py-2 rounded"
            style={{ color: 'white', fontWeight: '600', transition: 'background-color 0.3s' }}
            onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#1e8449')}
            onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
          >
            <FaTools size={20} /> Update Maintenance
          </Link>
        </nav>

        <button
          className="btn mt-4 d-flex align-items-center justify-content-center gap-2"
          onClick={handleLogout}
          style={{
            backgroundColor: '#e74c3c',
            border: 'none',
            fontWeight: '600',
            padding: '0.6rem',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'background-color 0.3s',
          }}
          onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#c0392b')}
          onMouseLeave={e => (e.currentTarget.style.backgroundColor = '#e74c3c')}
        >
          <FaSignOutAlt size={18} /> Logout
        </button>
      </div>

      {/* Main content */}
      <div className="flex-grow-1 d-flex flex-column" style={{ minHeight: '100vh' }}>
        {/* Topbar */}
        <div
          className="d-flex justify-content-between align-items-center px-4"
          style={{
            backgroundColor: '#2ecc71',
            color: 'white',
            height: '60px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
            position: 'sticky',
            top: 0,
            zIndex: 100,
          }}
        >
          <h5 className="mb-0" style={{ fontWeight: '600' }}>
            Welcome, Technician
          </h5>
          <img
            src="https://i.pravatar.cc/40?img=12"
            alt="Technician"
            className="rounded-circle"
            width="40"
            height="40"
            style={{ border: '2px solid white' }}
          />
        </div>

        {/* Main area */}
        <div className="p-4 flex-grow-1" style={{ backgroundColor: '#f5f9f6' }}>
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default TechnicianLayout;
