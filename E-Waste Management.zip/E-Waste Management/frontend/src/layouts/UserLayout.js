// src/layouts/UserLayout.js
import React, { useState, useEffect } from "react";
import { Outlet, Link, useLocation } from "react-router-dom";
import axios from "axios";
import userAvatar from "../assets/user-avatar.png";
import { FaMapMarkerAlt } from "react-icons/fa";
import Chatbot from "../components/Chatbot";

const user = JSON.parse(localStorage.getItem("user"));

const UserLayout = () => {
  const location = useLocation();
  const [userLocation, setUserLocation] = useState(null);
  const [credits, setCredits] = useState(null);

  // Geolocation
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        const apiKey = "000ba686a65d47db952e63f286e4255c";
        const apiUrl = `https://api.opencagedata.com/geocode/v1/json?q=${latitude}+${longitude}&key=${apiKey}`;
        try {
          const resp = await fetch(apiUrl);
          const data = await resp.json();
          const comps = data.results?.[0]?.components || {};
          const locality = comps.village || comps.town || comps.hamlet || comps.city || comps.suburb;
          const district = comps.state;
          setUserLocation(locality && district ? `${locality}, ${district}` : "Location unavailable");
        } catch {
          setUserLocation("Location unavailable");
        }
      }, () => setUserLocation("Location unavailable"));
    } else {
      setUserLocation("Geolocation not supported");
    }
  }, []);

  // Credits
  useEffect(() => {
    const fetchCredits = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await axios.get("/api/subscription/my-subscription", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setCredits(res.data.subscription?.credits ?? 0);
      } catch (err) {
        console.error("Failed to load credits:", err);
        setCredits(0);
      }
    };
    fetchCredits();
  }, []);

  const navLinks = [
    
    { path: "/user/add-inventory", label: "Add Assets" },
    { path: "/user/view-inventory", label: "View Assets" },
    { path: "/user/maintenance-history", label: "Maintenance History" },
    { path: "/user/request-pickup", label: "Request Pickup" },
    { path: "/user/pickup-history", label: "Pickup History" },
    { path: "/user/my-subscription", label: "My Subscription" },
  ];

  return (
    <div>
      {/* Sidebar */}
      <div
        className="bg-success text-white d-flex flex-column"
        style={{ position: "fixed", top: 0, left: 0, bottom: 0, width: "250px", padding: "20px", overflowY: "auto" }}
      >
        <h4 className="text-center mb-4">User Panel</h4>
        <ul className="nav flex-column">
          {navLinks.map((link) => (
            <li className="nav-item mb-2" key={link.path}>
              <Link
                to={link.path}
                className={`nav-link px-3 py-2 my-1 ${
                  location.pathname === link.path ? "bg-white text-success fw-bold rounded shadow-sm" : "text-white"
                }`}
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="mt-auto pt-3">
          <Link to="/logout" className="btn btn-outline-light w-100">
            Logout
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1" style={{ marginLeft: "250px", minHeight: "100vh" }}>
        {/* Top Navbar */}
        <div className="d-flex justify-content-between align-items-center border-bottom px-4 py-3 bg-white shadow-sm"
          style={{ position: "sticky", top: 0, zIndex: 1000 }}>
          <h5 className="mb-0 text-success">Welcome, {user?.name || "User"} 👋</h5>

          <div className="d-flex align-items-center">
            {userLocation && (
              <div className="d-flex align-items-center me-4">
                <FaMapMarkerAlt className="text-success me-2" />
                <span className="text-muted" style={{ fontSize: "14px" }}>{userLocation}</span>
              </div>
            )}
            {credits != null && (
              <div className="me-4">
                <span className="badge bg-info text-dark">Credits: {credits}</span>
              </div>
            )}

            {/* Avatar */}
            <img
              src={userAvatar}
              alt="User"
              className="rounded-circle"
              width="40"
              height="40"
              style={{ cursor: "default" }}
              title="User Avatar"
            />
          </div>
        </div>

        {/* Page Content */}
        <div className="p-4">
          <Outlet />
        </div>
      </div>

      <Chatbot />
    </div>
  );
};

export default UserLayout;
