import React from 'react';
import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { Button, Navbar, Container, Image } from 'react-bootstrap';
import { FiLogOut } from 'react-icons/fi'; // Logout icon from react-icons

const AdminLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div style={{ display: 'flex' }}>
      {/* Sticky Sidebar */}
      <div
        style={{
          width: '220px',
          height: '100vh',
          backgroundColor: '#2f7d32',
          color: 'white',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          position: 'fixed',
          top: 0,
          left: 0,
          zIndex: 1000,
          padding: '20px',
        }}
      >
        <div>
          <h4 className="text-white mb-4">Admin Panel</h4>
          <ul className="nav flex-column">
            <li className="nav-item">
              <Link
                to="/admin"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                📊 Dashboard
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/admin/users"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin/users' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                👥 Users
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/admin/technicians"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin/technicians' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                🛠 Technicians
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/admin/recyclers"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin/recyclers' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                🔄 Recyclers
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/admin/pickups"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin/pickups' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                🚚 Pickup Requests
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/admin/maintenance"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin/maintenance' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                🔧 Maintenance
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/admin/inventory"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin/inventory' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                📦 Inventory
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/admin/subscription-report"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin/subscription-report' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                💳 Subscriptions
              </Link>
            </li>
            <li className="nav-item">
              <Link
                to="/admin/system-report"
                className={`nav-link text-black px-3 py-2 rounded ${
                  location.pathname === '/admin/system-report' ? 'bg-white text-dark fw-bold' : ''
                }`}
              >
                📊 System Report
              </Link>
            </li>
          </ul>
        </div>

        <div className="mt-4">
          <Button
            variant="light"
            className="w-100 d-flex align-items-center justify-content-center gap-2 fw-semibold text-danger border-0 rounded shadow-sm"
            onClick={handleLogout}
            style={{ transition: 'background-color 0.3s ease' }}
            onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#f8d7da')}
            onMouseLeave={e => (e.currentTarget.style.backgroundColor = '')}
          >
            <FiLogOut size={20} />
            Logout
          </Button>
        </div>
      </div>

      {/* Right side container (topbar + content) */}
      <div style={{ marginLeft: '220px', width: '100%' }}>
        {/* Sticky Topbar */}
        <Navbar
          bg="light"
          className="px-4 shadow-sm"
          style={{
            position: 'fixed',
            top: 0,
            left: '220px',
            right: 0,
            zIndex: 999,
            height: '60px',
          }}
        >
          <Container fluid className="justify-content-end">
            <span className="me-3 fw-bold">Welcome, Admin</span>
            <Image
              src="https://i.pravatar.cc/40"
              roundedCircle
              alt="Profile"
              width="40"
              height="40"
            />
          </Container>
        </Navbar>

        {/* Scrollable Main Content */}
        <div
          style={{
            padding: '80px 20px 20px 20px', // padding-top: 80px to avoid hiding behind navbar
            backgroundColor: '#f0fff0',
            minHeight: '100vh',
            overflowY: 'auto',
          }}
        >
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
