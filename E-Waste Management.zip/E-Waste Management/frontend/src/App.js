import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Awareness from './pages/Awareness';

import AdminDashboard from './pages/AdminDashboard';
import Inventory from './pages/Inventory';
import AdminLayout from './layouts/AdminLayout';
import RecyclerLayout from './layouts/RecyclerLayout';
import UserLayout from './layouts/UserLayout';

import Navbar from './components/Navbar';
import Footer from './components/Footer';

import UserProfile from './components/UserProfile';
import UserDashboard from './pages/UserDashboard';
import RequestPickupForm from './components/RequestPickupForm';
import PickupHistory from './components/PickupHistory';
import ViewInventory from './components/ViewInventory';
import AddInventory from './components/AddInventory';
import ScheduleMaintenance from './components/ScheduleMaintenance';
import MaintenanceHistory from './components/MaintenanceHistory';

import RecyclerDashboard from './components/RecyclerDashboard';
import UpdateStatus from './components/UpdateStatus';
import Logout from "./pages/Logout";
import AdminUsers from './components/admin/AdminUsers';
import AdminRecyclers from './components/admin/AdminRecyclers';
import AdminPickupRequests from './components/admin/AdminPickupRequests';
import AdminMaintenance from './components/admin/AdminMaintenance';
import AdminInventory from './components/admin/AdminInventory';

import AssignedPickups from './components/recycler/AssignedPickups';
import CompletedPickups from './components/recycler/CompletedPickups';

import MySubscription from './components/MySubscription';

import TechnicianLayout from './layouts/TechnicianLayout';

import TechnicianDashboard from './components/technician/TechnicianDashboard';

import AssignedTasks from './components/technician/AssignedTasks';
import UpdateMaintenance from './components/technician/UpdateMaintenance';
import AdminTechnicians from './components/admin/AdminTechnicians';
import OurServices from './pages/OurServices';
import AdminSubscriptions from './components/admin/AdminSubscriptions';
import AdminSystemReport from './components/admin/AdminSystemReport';

function App() {
  const location = useLocation();
  const user = JSON.parse(localStorage.getItem('user'));
  const role = user?.role;

  const hideNavAndFooter =
    location.pathname.startsWith('/admin') ||
    location.pathname.startsWith('/recycler') ||
    location.pathname.startsWith('/technician') ||
    location.pathname.startsWith('/user');

  // 🔐 Role-based access control
  if (
    (location.pathname.startsWith('/user') && role !== 'user') ||
    (location.pathname.startsWith('/admin') && role !== 'admin') ||
    (location.pathname.startsWith('/recycler') && role !== 'recycler') ||
    (location.pathname.startsWith('/technician') && role !== 'technician')
  ) {
    window.location.href = '/login';
    return null;
  }  

  return (
    <div className="d-flex flex-column min-vh-100"> {/* Flex wrapper */}
      {!hideNavAndFooter && <Navbar />}

      <div className="flex-grow-1"> {/* Main Content */}
      
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/awareness" element={<Awareness />} />
          <Route path="/ourservices" element={<OurServices />} />
          <Route path="/logout" element={<Logout />} />

          {/* User Routes */}
          <Route path="/user" element={<UserLayout />}>
            <Route index element={<UserDashboard />} />
            <Route path="profile" element={<UserProfile />} />
            <Route path="request-pickup" element={<RequestPickupForm />} />
            <Route path="pickup-history" element={<PickupHistory />} />
            <Route path="view-inventory" element={<ViewInventory />} />
            <Route path="add-inventory" element={<AddInventory />} />
            <Route path="schedule-maintenance" element={<ScheduleMaintenance />} />
            <Route path="maintenance-history" element={<MaintenanceHistory />} />
            <Route path="my-subscription" element={<MySubscription />} />
          </Route>

          {/* Admin Routes */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="recyclers" element={<AdminRecyclers />} />
            <Route path="technicians" element={<AdminTechnicians />} />
            <Route path="pickups" element={<AdminPickupRequests />} />
            <Route path="maintenance" element={<AdminMaintenance />} />
            <Route path="inventory" element={<AdminInventory />} />
            <Route path="dashboard" element={<AdminDashboard />} />
            <Route path="subscription-report" element={<AdminSubscriptions />} />
            <Route path="system-report" element={<AdminSystemReport />} />
          </Route>

          {/* Recycler Routes */}
          <Route path="/recycler" element={<RecyclerLayout />}>
            <Route path="dashboard" element={<RecyclerDashboard />} />
            <Route path="assigned-pickups" element={<AssignedPickups />} />
            <Route path="completed-pickups" element={<CompletedPickups />} />
            <Route path="update-status" element={<UpdateStatus />} />
          </Route>

          <Route path="/technician-dashboard" element={<TechnicianLayout />}>
            <Route index element={<TechnicianDashboard />} />
            <Route path="assigned-tasks" element={<AssignedTasks />} />
            <Route path="update-maintenance" element={<UpdateMaintenance />} />
          </Route>

        </Routes>
      </div>

      {!hideNavAndFooter && <Footer />} {/* Always at the bottom if visible */}
    </div>
  );
}

export default App;
