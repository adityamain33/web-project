import express from 'express';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import cors from 'cors';
import axios from 'axios';

// Route Imports
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';
import inventoryRoutes from './routes/inventoryRoutes.js';
import pickupRoutes from './routes/pickupRoutes.js';
import recyclerRoutes from './routes/recyclerRoutes.js';
import maintenanceRoutes from './routes/maintenanceRoutes.js';
import adminUserRoutes from './routes/admin/adminUserRoutes.js';
import adminRecyclerRoutes from './routes/admin/adminRecyclerRoutes.js';
import adminPickupRoutes from './routes/admin/adminPickupRoutes.js';
import adminMaintenanceRoutes from './routes/admin/adminMaintenanceRoutes.js';
import adminInventoryRoutes from './routes/admin/adminInventoryRoutes.js';
import adminStatsRoutes from './routes/admin/adminStatsRoutes.js';
import recyclerPickupRoutes from './routes/recycler/recyclerPickupRoutes.js';
import subscriptionRoutes from './routes/subscriptionRoutes.js';

import paymentRoutes from './routes/paymentRoutes.js';

import adminTechnicianRoutes from './routes/admin/adminTechnicianRoutes.js';

import adminSubscriptionRoutes from './routes/admin/adminSubscriptionRoutes.js';

import adminReportRoutes from './routes/admin/adminReportRoutes.js';


// Config
import connectDB from './config/db.js';
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to DB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/pickups', pickupRoutes);
app.use('/api/recycler', recyclerRoutes);
app.use('/api/maintenance', maintenanceRoutes);
app.use('/api/admin/users', adminUserRoutes);
app.use('/api/admin/recyclers', adminRecyclerRoutes);
app.use('/api/admin/pickups', adminPickupRoutes);
app.use('/api/admin/maintenance', adminMaintenanceRoutes);
app.use('/api/admin', adminInventoryRoutes);
app.use('/api/admin', adminStatsRoutes);
app.use('/api/recycler/pickups', recyclerPickupRoutes);
app.use('/api/subscription', subscriptionRoutes);

app.use('/api/payment', paymentRoutes);

app.use('/uploads', express.static('uploads'));

app.use('/api/admin/technicians', adminTechnicianRoutes);

import technicianAssignedTasksRoutes from './routes/technician/technicianAssignedTasks.js';

app.use('/api/technician', technicianAssignedTasksRoutes);

import technicianUpdateMaintenance from './routes/technician/technicianUpdateMaintenance.js';

app.use('/api/technician', technicianUpdateMaintenance);

import technicianDashboardRoutes from './routes/technician/technicianDashboardRoutes.js';

app.use('/api/technician', technicianDashboardRoutes);

app.use('/api/admin', adminSubscriptionRoutes);

app.use('/api/admin', adminReportRoutes);




// allow up to 10MB JSON payloads
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ limit: '10mb', extended: true }))


// Chatbot Route
app.post("/api/chat", async (req, res) => {
  const userMessage = req.body.message;

  try {
    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: userMessage }],
        max_tokens: 150,
        temperature: 0.7,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    const botMessage = response.data.choices[0].message.content;
    res.json({ message: botMessage });
  } catch (error) {
    console.error("🔴 OpenAI API Error:", error.response?.data || error.message);
    res.status(500).json({ message: "Something went wrong with OpenAI API" });
  }
});

// Root Route
app.get('/', (req, res) => {
  res.send('E-Waste Management Backend Running');
});

// ✅ Final Single Listen Call
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
