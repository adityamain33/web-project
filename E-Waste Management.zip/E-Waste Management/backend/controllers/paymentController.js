// controllers/paymentController.js
import dotenv from 'dotenv';
import paypal from 'paypal-rest-sdk';

dotenv.config();

paypal.configure({
  mode: 'sandbox', // Use 'live' for production
  client_id: process.env.PAYPAL_CLIENT_ID,
  client_secret: process.env.PAYPAL_CLIENT_SECRET,
});

export const createOrder = async (req, res) => {
  try {
    const { amount } = req.body;
    if (amount == null || isNaN(amount) || amount <= 0) {
      return res.status(400).json({ message: 'Invalid amount for paid plan' });
    }

    // Setup payment details for PayPal
    const paymentData = {
      intent: 'sale',
      payer: {
        payment_method: 'paypal',
      },
      transactions: [
        {
          amount: {
            total: amount.toString(), // amount as string
            currency: 'USD',
          },
          description: 'Payment for subscription plan',
        },
      ],
      redirect_urls: {
        return_url: 'http://localhost:3000/payment/success', // Replace with actual success URL
        cancel_url: 'http://localhost:3000/payment/cancel', // Replace with actual cancel URL
      },
    };

    // Create PayPal payment
    paypal.payment.create(paymentData, (error, payment) => {
      if (error) {
        console.error('PayPal Order Error:', error);
        return res.status(500).json({ message: 'Failed to create PayPal order', error: error.message });
      }

      // Check for approval URL
      const approvalUrl = payment.links.find(link => link.rel === 'approval_url');
      if (approvalUrl) {
        return res.json({ approvalUrl: approvalUrl.href, paymentId: payment.id });
      } else {
        return res.status(500).json({ message: 'No approval URL found in PayPal response' });
      }
    });
  } catch (error) {
    console.error('PayPal Order Error:', error);
    return res.status(500).json({ message: 'Failed to create PayPal order', error: error.message });
  }
};
