import Asset from '../models/AssetModel.js';

// ✅ Add Inventory
export const addInventory = async (req, res) => {
  try {
    const {
      deviceName,
      category,
      quantity,
      condition,
      description,
      brand,
      warrantyStatus,
      purchaseYear,
    } = req.body;

    // Basic validation
    if (!deviceName || !category || !quantity || !condition || !brand || !warrantyStatus || !purchaseYear) {
      return res.status(400).json({ message: 'All required fields must be filled' });
    }

    // Check for valid user from verifyToken
    if (!req.user || !req.user.id) {
      return res.status(401).json({ message: 'Unauthorized. User info missing.' });
    }

    // Create and save inventory item
    const newItem = new Asset({
      deviceName,
      category,
      quantity,
      condition,
      description: description || '',
      brand,
      warrantyStatus,
      purchaseYear,
      addedBy: req.user.id,
    });

    const savedItem = await newItem.save();

    res.status(201).json({
      message: 'Inventory added successfully',
      item: savedItem,
    });
  } catch (err) {
    console.error('Error adding inventory:', err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};


// ✅ Get Inventory of Logged-In User
export const getUserInventory = async (req, res) => {
  try {
    const items = await Asset.find({ addedBy: req.user.id }).sort({ createdAt: -1 });
    res.status(200).json(items);
  } catch (err) {
    console.error('Error fetching user inventory:', err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

// ✅ Get All Inventory (Admin)
export const getAllInventory = async (req, res) => {
  try {
    const items = await Asset.find().populate('addedBy', 'name email'); // Optional
    res.status(200).json(items);
  } catch (err) {
    console.error('Error fetching all inventory:', err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};
