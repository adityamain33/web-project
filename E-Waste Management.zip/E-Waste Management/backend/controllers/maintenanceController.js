import Maintenance from '../models/maintenanceModel.js';
import Inventory from '../models/AssetModel.js'; // make sure this path is correct

export const scheduleMaintenance = async (req, res) => {
  try {
    const {
      inventoryId,
      maintenanceType,
      preferredDate,
      preferredTime,
      notes,
    } = req.body;

    // Fetch asset details using inventoryId
    const asset = await Inventory.findById(inventoryId);
    if (!asset) {
      return res.status(404).json({ message: 'Asset not found' });
    }

    const imagePath = req.file ? req.file.path : asset.image || '';

    const newMaintenance = new Maintenance({
      userId: req.user.id,
      deviceName: asset.deviceName,
      maintenanceType,
      preferredDate,
      preferredTime,
      notes,
      image: imagePath,
      status: 'Scheduled',
    });

    await newMaintenance.save();
    res.status(201).json({ message: 'Maintenance scheduled successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error scheduling maintenance' });
  }
};

export const getMaintenanceHistory = async (req, res) => {
  try {
    const history = await Maintenance.find({ userId: req.user.id })
      .populate('assetId', 'deviceName')            // Only fetch asset name
      .populate('technicianId', 'name');      // Only fetch technician name

    res.json(history);
  } catch (err) {
    console.error('Error fetching history:', err);
    res.status(500).json({ error: 'Failed to fetch history' });
  }
};
