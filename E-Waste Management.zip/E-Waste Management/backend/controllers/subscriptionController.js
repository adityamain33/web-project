import mongoose from "mongoose";
import UserSubscription from "../models/UserSubscription.js";

// Static subscription plans
const subscriptionPlans = [
  {
    id: "basic",
    name: "Basic Plan",
    price: 0,
    credits: 2,
    durationInDays: 30,
    description: "Free plan with 2 pickups/month",
  },
  {
    id: "standard",
    name: "Standard Plan",
    price: 2.5,
    credits: 5,
    durationInDays: 30,
    description: "Monthly plan with 5 pickups",
  },
  {
    id: "premium",
    name: "Premium Plan",
    price: 5,
    credits: 10,
    durationInDays: 30,
    description: "Monthly plan with 10 pickups",
  },
];

// Get all available plans
export const getPlans = (req, res) => {
  const mapped = subscriptionPlans.map((p) => ({
    id: p.id,
    name: p.name,
    amount: p.price,
    credits: p.credits,
    durationInDays: p.durationInDays,
    description: p.description,
  }));

  res.json({ plans: mapped });
};

// Subscribe to a plan
export const subscribeToPlan = async (req, res) => {
  try {
    const userId = req.user._id;
    const { planId } = req.body;

    const plan = subscriptionPlans.find((p) => p.id === planId);
    if (!plan) {
      return res.status(400).json({ message: "Invalid plan selected" });
    }

    const existing = await UserSubscription.findOne({ userId });

    if (existing && plan.price === 0) {
      return res
        .status(400)
        .json({ message: "You have already used the free plan." });
    }

    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + plan.durationInDays);

    const updatedSub = await UserSubscription.findOneAndUpdate(
      { userId },
      {
        userId,
        planId: plan.id,
        startDate: new Date(),
        validTill: expiryDate,
        remainingPickups: plan.credits,
        isActive: true,
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    res.status(200).json({
      message: "Subscribed successfully",
      subscription: {
        planName: plan.name,
        credits: updatedSub.remainingPickups,
        expiryDate: updatedSub.validTill,
        isActive: updatedSub.isActive,
      },
    });
  } catch (err) {
    console.error("Error in subscribeToPlan:", err);
    res.status(500).json({ message: "Subscription failed" });
  }
};

// Get current subscription
export const getMySubscription = async (req, res) => {
  try {
    const userId = req.user._id;
    const subscription = await UserSubscription.findOne({ userId });

    const plans = subscriptionPlans.map((p) => ({
      id: p.id,
      name: p.name,
      amount: p.price,
      credits: p.credits,
      durationInDays: p.durationInDays,
      description: p.description,
    }));

    if (!subscription) {
      return res.json({ subscription: null, plans });
    }

    if (new Date(subscription.validTill) < new Date()) {
      subscription.isActive = false;
      await subscription.save();
    }

    const plan = subscriptionPlans.find((p) => p.id === subscription.planId);
    if (!plan) {
      return res.status(500).json({ message: "Plan info missing" });
    }

    res.json({
      subscription: {
        planName: plan.name,
        credits: subscription.remainingPickups,
        expiryDate: subscription.validTill,
        isActive: subscription.isActive,
      },
      plans,
    });
  } catch (err) {
    console.error("Failed to fetch subscription:", err);
    res.status(500).json({ message: "Failed to fetch subscription" });
  }
};
