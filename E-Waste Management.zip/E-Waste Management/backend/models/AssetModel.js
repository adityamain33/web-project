import mongoose from 'mongoose';

const assetSchema = new mongoose.Schema({
  deviceName: {
    type: String,
    required: true,
  },
  category: {
    type: String,
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
  },
  brand: {
    type: String,
    required: true,
  },
  modelNumber: {
    type: String,
  },
  purchaseYear: {
    type: Number,
    required: true,
  },
  warrantyStatus: {
    type: String,
    enum: ['Valid', 'Expired'],
    required: true,
  },
  condition: {
    type: String,
    enum: ['Working', 'Damaged', 'Dead'],
    required: true,
  },
  description: {
    type: String, // Optional
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Auto-populate the 'addedBy' field with 'name'
assetSchema.pre('find', function () {
  this.populate('addedBy', 'name');
});

const Asset = mongoose.models.Asset || mongoose.model('Asset', assetSchema);

export default Asset;
