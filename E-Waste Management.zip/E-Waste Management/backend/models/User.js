import mongoose from 'mongoose';

// Define the User schema
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    required: true,
    enum: ['user', 'recycler','technician'],
  },
  // Common fields
  mobile: {
    type: String,
  },
  // Recycler-specific fields
  organization: {
    type: String,
  },
  location: {
    type: String,
  },
  assignedUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null }, // Add this line
}, {
  timestamps: true, // Automatically add createdAt and updatedAt
});

// Create and export the User model
const User = mongoose.model('User', userSchema);
export default User;
