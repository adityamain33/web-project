import mongoose from 'mongoose';

const maintenanceSchema = new mongoose.Schema({
  assetId: { type: mongoose.Schema.Types.ObjectId, ref: 'Asset', required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  technicianId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  scheduledDate: { type: String, required: true },
  scheduledTime: { type: String, required: true },
  notes: { type: String },
  issueDescription: { type: String },        // <-- add this
  technicianRemark: { type: String },        // <-- add this for remarks
  status: { type: String, default: 'Scheduled' }
}, {
  timestamps: true,
});

export default mongoose.model('Maintenance', maintenanceSchema);
