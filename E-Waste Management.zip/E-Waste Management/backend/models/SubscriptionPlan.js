import mongoose from 'mongoose';

const SubscriptionPlanSchema = new mongoose.Schema({
  name: String,
  price: Number,
  pickupsAllowed: Number,
  validityDays: Number // e.g., 30
});

export default mongoose.model("SubscriptionPlan", SubscriptionPlanSchema);
