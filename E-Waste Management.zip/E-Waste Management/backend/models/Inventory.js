import mongoose from 'mongoose';

const inventorySchema = new mongoose.Schema({
  itemName: {
    type: String,
    required: true,
  },
  category: {
    type: String,
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
    default: 1,
  },
  condition: {
    type: String, // e.g., Recycled, Working, Disposed, etc.
    enum: ['Recycled', 'Repairable', 'Working', 'Disposed', 'Sold'],
    default: 'Recycled',
  },
  addedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // likely a Recycler or Admin
  },
  sourcePickupId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PickupRequest',
  },
  addedOn: {
    type: Date,
    default: Date.now,
  },
});

export default mongoose.model('Inventory', inventorySchema);
