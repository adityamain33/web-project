import mongoose from 'mongoose';

// Define the Recycler schema
const recyclerSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  location: {
    type: String,
    required: true,
  },
  // Add other fields as required
}, {
  timestamps: true, // Automatically add createdAt and updatedAt
});

// Create and export the Recycler model
const Recycler = mongoose.model('Recycler', recyclerSchema);
export default Recycler;
