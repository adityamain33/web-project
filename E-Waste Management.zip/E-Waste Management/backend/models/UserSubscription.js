import mongoose from 'mongoose';

const userSubscriptionSchema = new mongoose.Schema({
  userId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  planId: { 
    type: String, 
    ref: 'SubscriptionPlan', 
    required: true 
  },
  startDate: { 
    type: Date, 
    required: true, 
    default: Date.now 
  },
  validTill: { 
    type: Date, 
    required: true 
  },
  remainingPickups: { 
    type: Number, 
    required: true, 
    default: 0 
  },
  isActive: { 
    type: Boolean, 
    required: true, 
    default: true 
  }
}, { timestamps: true });

export default mongoose.model('UserSubscription', userSubscriptionSchema);
