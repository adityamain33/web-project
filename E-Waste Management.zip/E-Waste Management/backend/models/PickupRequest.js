import mongoose from 'mongoose';

const pickupRequestSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    itemName: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    quantity: {
      type: Number,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    preferredDate: {
      type: Date,
      required: true,
    },
    timeSlot: {
      type: String,
      required: true,
    },
    notes: {
      type: String,
    },
    deviceCondition: {
      type: String,
      required: true,
    },
    expectedValue: {
      type: Number,
    },
    willingToSell: {
      type: String,
      required: true,
    },
    itemImage: {
      type: String, // Store the base64 or URL of the image
      default: '',
    },
    status: {
      type: String,
      default: 'pending',
    },
    assignedRecycler: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { timestamps: true }
);

const PickupRequest = mongoose.model('PickupRequest', pickupRequestSchema);

export default PickupRequest;  // Changed from `module.exports = PickupRequest;` to `export default PickupRequest;`
