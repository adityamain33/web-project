import express from 'express';
import {
  addInventory,
  getUserInventory,
  getAllInventory
} from '../controllers/inventoryController.js';
import { verifyToken, verifyAdmin } from '../middleware/authMiddleware.js';
import Asset from '../models/AssetModel.js'; // 🛠️ Required for delete/update logic

const router = express.Router();

// ✅ Add Inventory (User)
router.post('/add', verifyToken, addInventory);

// ✅ Get User's Inventory
router.get('/user', verifyToken, getUserInventory);

// ✅ Get All Inventory (Admin Dashboard)
router.get('/', verifyToken, verifyAdmin, getAllInventory);

// ✅ DELETE Inventory by ID
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    await Inventory.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Delete failed' });
  }
});

// ✅ UPDATE Inventory by ID
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const updated = await Inventory.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

export default router;
