import express from 'express';
import PickupRequest from '../../models/PickupRequest.js';
import { verifyToken } from '../../middleware/authMiddleware.js';
import User from '../../models/User.js';

const router = express.Router();

// GET /api/admin/pickups - Fetch all pickup requests for the admin
router.get('/', verifyToken, async (req, res) => {
  try {
    const pickups = await PickupRequest.find()
      .populate('userId', 'name')
      .populate('assignedRecycler', 'name');

    res.json(pickups);
  } catch (err) {
    console.error('Error fetching pickup requests:', err);
    res.status(500).json({ error: 'Failed to fetch pickup requests' });
  }
});

// GET /api/admin/recyclers - Get all recyclers
router.get('/recyclers', verifyToken, async (req, res) => {
  try {
    const recyclers = await User.find({ role: 'recycler' });
    res.json(recyclers);
  } catch (error) {
    console.error('Error fetching recyclers:', error);
    res.status(500).json({ message: 'Server Error' });
  }
});

// PUT /api/admin/pickups/:id/assign - Assign recycler to pickup request
router.put('/:id/assign', verifyToken, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied: Admins only' });
  }

  const { recyclerId } = req.body;

  try {
    if (!recyclerId) {
      return res.status(400).json({ error: 'Recycler ID is required' });
    }

    const updated = await PickupRequest.findByIdAndUpdate(
      req.params.id,
      {
        assignedRecycler: recyclerId,
        status: 'assigned',
      },
      { new: true }
    ).populate('userId', 'name')
     .populate('assignedRecycler', 'name');

    if (!updated) {
      return res.status(404).json({ error: 'Pickup request not found' });
    }

    res.json(updated);
  } catch (err) {
    console.error('Error assigning recycler:', err);
    res.status(500).json({ error: 'Failed to assign recycler' });
  }
});

// PUT /api/admin/pickups/:id/status - Update pickup request status
router.put('/:id/status', verifyToken, async (req, res) => {
  const { status } = req.body;

  try {
    if (!status) {
      return res.status(400).json({ error: 'Status is required' });
    }

    const updated = await PickupRequest.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    ).populate('userId', 'name')
     .populate('assignedRecycler', 'name');

    if (!updated) {
      return res.status(404).json({ error: 'Pickup request not found' });
    }

    res.json(updated);
  } catch (err) {
    console.error('Error updating status:', err);
    res.status(500).json({ error: 'Failed to update status' });
  }
});

export default router;
