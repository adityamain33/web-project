import express from 'express';
import Inventory from '../../models/Inventory.js';
import { verifyToken } from '../../middleware/authMiddleware.js';

const router = express.Router();

// @route   GET /api/admin/inventory
// @desc    Get all inventory records (admin only)
// @access  Private
router.get('/inventory', verifyToken, async (req, res) => {
  try {
    const inventories = await Inventory.find()
      .populate('addedBy', 'name')
      .populate({
        path: 'sourcePickupId',
        select: 'status'  // Sirf pickup ka status chahiye
      })
      .exec();

    // Optional: Agar tum chaho, toh response mein pickup status ko seedha top-level property bana sakte ho
    const formattedInventories = inventories.map(item => ({
      _id: item._id,
      itemName: item.itemName,
      category: item.category,
      quantity: item.quantity,
      condition: item.condition,
      addedBy: item.addedBy,
      addedOn: item.addedOn,
      sourcePickupId: item.sourcePickupId?._id || null,
      pickupStatus: item.sourcePickupId?.status || 'Unknown', // pickup status yahan se
    }));

    res.json(formattedInventories);
  } catch (err) {
    console.error('Error fetching inventory:', err);
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

export default router;
