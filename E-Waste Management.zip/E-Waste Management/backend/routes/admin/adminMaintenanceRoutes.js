// routes/adminMaintenanceRoutes.js
import express from 'express';
import { verifyToken } from '../../middleware/authMiddleware.js';
import Maintenance from '../../models/maintenanceModel.js';
import User from '../../models/User.js';

const router = express.Router();

// GET /api/admin/maintenance - fetch all maintenance requests
router.get('/', verifyToken, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied' });
  }

  try {
    const records = await Maintenance.find()
      .populate('userId', 'name email')
      .sort({ createdAt: -1 });

    res.json(records);
  } catch (err) {
    console.error('Error fetching maintenance:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
