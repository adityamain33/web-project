import express from 'express';
import User from '../../models/User.js';
import PickupRequest from '../../models/PickupRequest.js';
import Asset from '../../models/AssetModel.js';
import Maintenance from '../../models/maintenanceModel.js';
import { verifyToken, verifyAdmin } from '../../middleware/authMiddleware.js';

const router = express.Router();

// Total Users
router.get('/users/count', verifyToken, verifyAdmin, async (req, res) => {
  const count = await User.countDocuments({ role: 'user' });
  res.json({ count });
});

// Total Recyclers
router.get('/recyclers/count', verifyToken, verifyAdmin, async (req, res) => {
  const count = await User.countDocuments({ role: 'recycler' });
  res.json({ count });
});

// Total Pickup Requests
router.get('/pickups/count', verifyToken, verifyAdmin, async (req, res) => {
  const count = await PickupRequest.countDocuments();
  res.json({ count });
});

// Pending / Completed Pickups
router.get('/pickups/count', verifyToken, verifyAdmin, async (req, res) => {
  const { status } = req.query;
  const count = await PickupRequest.countDocuments({ status });
  res.json({ count });
});

// Active Maintenance
router.get('/maintenance/count', verifyToken, verifyAdmin, async (req, res) => {
  const { status } = req.query;
  const count = await Maintenance.countDocuments({ status });
  res.json({ count });
});

export default router;
