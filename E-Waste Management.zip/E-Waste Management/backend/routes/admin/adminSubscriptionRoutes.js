// routes/admin/adminSubscriptionRoutes.js
import express from 'express';
import Subscription from '../../models/UserSubscription.js';
import User from '../../models/User.js';

const router = express.Router();

// GET all subscriptions with user info
router.get('/all-subscriptions', async (req, res) => {
  try {
    const subscriptions = await Subscription.find().populate('userId', 'name email');
    res.status(200).json(subscriptions);
  } catch (error) {
    console.error('Failed to fetch subscriptions:', error);
    res.status(500).json({ error: 'Failed to fetch subscriptions' });
  }
});

export default router;
