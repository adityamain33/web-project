import express from 'express';
import PickupRequest from '../../models/PickupRequest.js';
import Maintenance from '../../models/maintenanceModel.js';
import User from '../../models/User.js';
import UserSubscription from '../../models/UserSubscription.js';
import Inventory from '../../models/Inventory.js';

const router = express.Router();

router.get('/system-report', async (req, res) => {
  try {
    const range = req.query.range || 'monthly';
    const now = new Date();
    let startDate;

    if (range === 'monthly') {
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (range === 'quarterly') {
      const quarter = Math.floor(now.getMonth() / 3);
      startDate = new Date(now.getFullYear(), quarter * 3, 1);
    } else if (range === 'yearly') {
      startDate = new Date(now.getFullYear(), 0, 1);
    }

    const [
      pickupCount,
      completedPickups,
      maintenanceCount,
      newUsers,
      subscriptions,
      recyclerCount,
      technicianCount,
      totalAssets,

      totalPickups,
      totalCompleted,
      totalMaintenance,
      totalUsers,
      totalSubscriptions,
      totalRecyclers,
      totalTechnicians,
      allAssets
    ] = await Promise.all([
      PickupRequest.countDocuments({ createdAt: { $gte: startDate } }),
      PickupRequest.countDocuments({ status: 'completed', updatedAt: { $gte: startDate } }),
      Maintenance.countDocuments({ createdAt: { $gte: startDate } }),
      User.countDocuments({ createdAt: { $gte: startDate } }),
      UserSubscription.countDocuments({ startDate: { $gte: startDate } }),
      User.countDocuments({ role: 'recycler', createdAt: { $gte: startDate } }),
      User.countDocuments({ role: 'technician', createdAt: { $gte: startDate } }),
      Inventory.countDocuments({ createdAt: { $gte: startDate } }),

      // total values
      PickupRequest.estimatedDocumentCount(),
      PickupRequest.countDocuments({ status: 'completed' }),
      Maintenance.estimatedDocumentCount(),
      User.estimatedDocumentCount(),
      UserSubscription.estimatedDocumentCount(),
      User.countDocuments({ role: 'recycler' }),
      User.countDocuments({ role: 'technician' }),
      Inventory.estimatedDocumentCount()
    ]);

    res.json({
      range,
      pickupCount,
      completedPickups,
      maintenanceCount,
      newUsers,
      subscriptions,
      recyclerCount,
      technicianCount,
      totalAssets,

      totalPickups,
      totalCompleted,
      totalMaintenance,
      totalUsers,
      totalSubscriptions,
      totalRecyclers,
      totalTechnicians,
      allAssets
    });

  } catch (err) {
    console.error('Report error:', err);
    res.status(500).json({ error: 'Failed to generate system report' });
  }
});

export default router;
