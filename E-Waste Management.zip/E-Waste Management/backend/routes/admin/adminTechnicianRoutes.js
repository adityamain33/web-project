import express from 'express';
import User from '../../models/User.js';  // path tumhare structure ke hisaab se adjust kar lena

const router = express.Router();

// Get all technicians
router.get('/', async (req, res) => {
  try {
    const technicians = await User.find({ role: 'technician' })
      .select('-password')
      .populate('assignedUser', 'name email'); // populate assigned user with name and email only
    res.json(technicians);
  } catch (err) {
    console.error('Error fetching technicians:', err.message);
    res.status(500).json({ message: 'Server Error' });
  }
});


// Assign a user to a technician
router.patch('/assign-user/:technicianId', async (req, res) => {
  try {
    const { technicianId } = req.params;
    const { userId } = req.body;

    // Check technician exists
    const technician = await User.findOne({ _id: technicianId, role: 'technician' });
    if (!technician) {
      return res.status(404).json({ message: 'Technician not found' });
    }

    // Assign user to technician
    technician.assignedUser = userId;
    await technician.save();

    res.json({ message: 'User assigned to technician successfully', technician });
  } catch (error) {
    console.error('Error assigning user:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
});



export default router;
