// ❌ Wrong
// const express = require('express');

// ✅ Right
import express from 'express';
import User from '../../models/User.js'; // update with .js if needed

const router = express.Router();

router.get('/', async (req, res) => {
    try {
      const users = await User.find({ role: 'user' }).select('-password');
      res.json(users);
    } catch (err) {
      console.error('Error fetching users:', err.message);
      res.status(500).json({ message: 'Server Error' });
    }
  });
  

export default router;
