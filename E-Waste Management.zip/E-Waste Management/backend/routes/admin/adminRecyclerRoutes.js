import express from 'express';
import User from '../../models/User.js'; // Update with correct model path

const router = express.Router();

// Get all recyclers
router.get('/', async (req, res) => {
  try {
    // Filter by role 'recycler' to get only recyclers
    const recyclers = await User.find({ role: 'recycler' });
    res.json(recyclers);
  } catch (err) {
    console.error('Error fetching recyclers:', err.message);
    res.status(500).json({ message: 'Server Error' });
  }
});

// Delete recycler
router.delete('/:id', async (req, res) => {
  try {
    const recycler = await User.findByIdAndDelete(req.params.id);
    if (!recycler) {
      return res.status(404).json({ message: 'Recycler not found' });
    }
    res.json({ message: 'Recycler deleted successfully' });
  } catch (err) {
    console.error('Error deleting recycler:', err.message);
    res.status(500).json({ message: 'Server Error' });
  }
});

export default router;
