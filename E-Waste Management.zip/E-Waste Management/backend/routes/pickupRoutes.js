// routes/pickupRoutes.js
import express from 'express';
import multer from 'multer';
import path from 'path';
import { verifyToken } from '../middleware/authMiddleware.js';
import PickupRequest from '../models/PickupRequest.js';
import UserSubscription from '../models/UserSubscription.js';
import Recycler from '../models/Recycler.js'; // ✅ Correct this path if needed


const router = express.Router();

// 📦 Multer Setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '_' + file.originalname);
  },
});
const fileFilter = (req, file, cb) => {
  const allowed = ['.jpg', '.jpeg', '.png'];
  const ext = path.extname(file.originalname).toLowerCase();
  if (allowed.includes(ext)) cb(null, true);
  else cb(new Error('Only JPG, JPEG, PNG files allowed'), false);
};
const upload = multer({ storage, fileFilter });

/**
 * 📥 Create New Pickup Request
 * Endpoint to create a pickup request, validating subscription status and credits.
 */
router.post("/", verifyToken, async (req, res) => {
  try {
    const userId = req.user.id;
    const {
      itemName, category, quantity, address,
      preferredDate, timeSlot, notes,
      deviceCondition, expectedValue, willingToSell,
      itemImage
    } = req.body;

    // 1. Get the user's subscription info
    const subscription = await UserSubscription.findOne({ userId });

    if (!subscription) {
      return res.status(400).json({
        success: false,
        message: "You do not have an active subscription. Please subscribe first."
      });
    }

    // 2. Check if user has remaining pickups
    if (subscription.remainingPickups <= 0) {
      return res.status(400).json({
        success: false,
        message: "No credits left, please subscribe first."
      });
    }

    // 3. Create new pickup request
    const newRequest = new PickupRequest({
      userId,
      itemName,
      category,
      quantity,
      address,
      preferredDate,
      timeSlot,
      notes,
      deviceCondition,
      expectedValue,
      willingToSell,
      itemImage,
      status: "pending"
    });

    // 4. Save pickup request
    await newRequest.save();

    // 5. Decrement remainingPickups in subscription and save
    subscription.remainingPickups -= 1;
    await subscription.save();

    res.status(201).json({
      success: true,
      message: "Pickup request created successfully.",
      remainingPickups: subscription.remainingPickups
    });
  } catch (error) {
    console.error("❌ Error creating pickup:", error);
    res.status(500).json({
      success: false,
      message: "Failed to create pickup request",
      error: error.message || error
    });
  }
});


/**
 * 📄 Get all Pickup Requests for a User
 * Endpoint to fetch all the pickup requests made by the current user.
 */
router.get('/', verifyToken, async (req, res) => {
  try {
    const userId = req.user.id;

    // Fetch the user's pickup requests
    const pickups = await PickupRequest.find({ userId })
      .populate('assignedRecycler', 'name email')
      .sort({ createdAt: -1 })
      .select(
        'itemName category quantity address preferredDate timeSlot deviceCondition expectedValue willingToSell notes status itemImage createdAt updatedAt'
      );

    // Respond with the pickup data
    res.status(200).json({ success: true, data: pickups });
  } catch (error) {
    console.error('❌ Error fetching pickups:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
});

/**
 * 🗑️ Delete a Pickup Request (only if pending)
 * Endpoint to delete a pending pickup request.
 */
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const pickup = await PickupRequest.findById(req.params.id);

    if (!pickup) {
      return res.status(404).json({ success: false, message: 'Pickup not found' });
    }

    if (pickup.status.toLowerCase() !== 'pending') {
      return res.status(400).json({ success: false, message: 'Only pending requests can be deleted' });
    }

    if (pickup.userId.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized' });
    }

    // Delete the pickup request
    await pickup.deleteOne();
    res.status(200).json({ success: true, message: 'Pickup request deleted successfully' });
  } catch (error) {
    console.error('❌ Error deleting pickup:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
});

/**
 * ✏️ Update a Pickup Request (only if pending)
 * Endpoint to update a pending pickup request.
 */
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const pickup = await PickupRequest.findById(req.params.id);

    if (!pickup) {
      return res.status(404).json({ success: false, message: 'Pickup not found' });
    }

    if (pickup.status.toLowerCase() !== 'pending') {
      return res.status(400).json({ success: false, message: 'Only pending requests can be updated' });
    }

    if (pickup.userId.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized' });
    }

    // Extract the updated fields from the request body
    const {
      itemName,
      category,
      quantity,
      address,
      preferredDate,
      timeSlot,
      notes,
      deviceCondition,
      expectedValue,
      willingToSell,
      itemImage,
    } = req.body;

    // Update the pickup request with the new values
    pickup.itemName = itemName || pickup.itemName;
    pickup.category = category || pickup.category;
    pickup.quantity = quantity || pickup.quantity;
    pickup.address = address || pickup.address;
    pickup.preferredDate = preferredDate || pickup.preferredDate;
    pickup.timeSlot = timeSlot || pickup.timeSlot;
    pickup.notes = notes || pickup.notes;
    pickup.deviceCondition = deviceCondition || pickup.deviceCondition;
    pickup.expectedValue = expectedValue ?? pickup.expectedValue;
    pickup.willingToSell = willingToSell ?? pickup.willingToSell;
    pickup.itemImage = itemImage || pickup.itemImage;

    // Save the updated pickup request
    const updatedPickup = await pickup.save();
    res.status(200).json({
      success: true,
      message: 'Pickup request updated successfully.',
      data: updatedPickup,
    });
  } catch (error) {
    console.error('❌ Error updating pickup:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
});

export default router;
