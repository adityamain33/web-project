// backend/routes/maintenanceRoutes.js
import express from 'express';
import multer from 'multer';
import { verifyToken } from '../middleware/authMiddleware.js';
import { scheduleMaintenance, getMaintenanceHistory } from '../controllers/maintenanceController.js';

const router = express.Router();

// Multer config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/maintenance/');
  },
  filename: function (req, file, cb) {
    const ext = file.originalname.split('.').pop();
    cb(null, `mnt_${Date.now()}.${ext}`);
  },
});

const upload = multer({ storage });

router.post(
  '/schedule',
  verifyToken,
  upload.single('image'),
  scheduleMaintenance
);

router.get('/history', verifyToken, getMaintenanceHistory);

export default router;
