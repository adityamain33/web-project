// routes/paymentRoutes.js
import express from "express";
import { createOrder } from "../controllers/paymentController.js";

const router = express.Router();

// Create order for payment
router.post("/create-order", createOrder);

// Route to handle the PayPal payment success
router.get("/payment/success", (req, res) => {
  // You can implement the logic to capture the payment here
  // PayPal will send the payment ID and token after approval
  const paymentId = req.query.paymentId;
  const payerId = req.query.PayerID;

  // Call PayPal API to execute the payment
  paypal.payment.execute(paymentId, { payer_id: payerId }, function (error, payment) {
    if (error) {
      console.error(error);
      res.status(500).json({ message: 'Payment execution failed' });
    } else {
      res.status(200).json({ message: 'Payment successful', payment });
    }
  });
});

// Route to handle the PayPal payment cancellation
router.get("/payment/cancel", (req, res) => {
  res.status(200).json({ message: 'Payment was canceled by the user' });
});

export default router;
