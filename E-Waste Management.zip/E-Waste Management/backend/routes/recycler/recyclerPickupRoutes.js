// routes/recycler/recyclerPickupRoutes.js
import express from 'express';
import mongoose from 'mongoose';
import PickupRequest from '../../models/PickupRequest.js';
import Inventory from '../../models/Inventory.js';
import { verifyToken } from '../../middleware/authMiddleware.js';

const router = express.Router();

const inventoryStatuses = ['Recycled', 'Disposed', 'Completed']; // inventory me add karne wale statuses

// Get all pickups assigned to recycler
router.get('/assigned', verifyToken, async (req, res) => {
  try {
    const recyclerId = req.user.id;

    const pickups = await PickupRequest.find({ assignedRecycler: recyclerId })
      .populate('userId', 'name')
      .sort({ scheduledDate: 1 });

    res.json(pickups);
  } catch (err) {
    console.error('Error fetching assigned pickups:', err);
    res.status(500).json({ error: 'Failed to fetch assigned pickups' });
  }
});

// Update pickup status + add to inventory if applicable
router.put('/update-status/:pickupId', verifyToken, async (req, res) => {
  try {
    const { pickupId } = req.params;
    const { status } = req.body;

    const pickup = await PickupRequest.findById(pickupId);

    if (!pickup) {
      return res.status(404).json({ error: 'Pickup not found' });
    }

    if (!pickup.assignedRecycler || pickup.assignedRecycler.toString() !== req.user.id) {
      return res.status(403).json({ error: 'You are not authorized to update this pickup' });
    }

    pickup.status = status;
    await pickup.save();

    // Agar status inventory mein add karne wali category mein hai
    if (inventoryStatuses.includes(status)) {
      // Check kar le inventory mein pehle se added na ho
      const alreadyExists = await Inventory.findOne({ sourcePickupId: pickup._id });
      if (!alreadyExists) {
        const inventoryItem = new Inventory({
          itemName: pickup.itemName,
          category: pickup.category,
          quantity: pickup.quantity,
          condition: pickup.deviceCondition || 'Unknown',
          addedBy: req.user.id,
          sourcePickupId: pickup._id,
          status: status,
        });

        await inventoryItem.save();
      }
    }

    res.json({ message: 'Pickup status updated successfully', pickup });
  } catch (err) {
    console.error('Error updating pickup status:', err);
    res.status(500).json({ error: 'Failed to update pickup status' });
  }
});

// Get completed pickups assigned to recycler
router.get('/completed-pickups', verifyToken, async (req, res) => {
  try {
    const recyclerId = req.user.id;

    const pickups = await PickupRequest.find({
      assignedRecycler: new mongoose.Types.ObjectId(recyclerId),
      status: 'Completed'
    }).populate('userId', 'name');

    res.json(pickups);
  } catch (err) {
    console.error('Error fetching completed pickups:', err);
    res.status(500).json({ error: 'Failed to fetch completed pickups' });
  }
});

// Mark pickup as completed and add to inventory (optional route, can keep or remove)
router.put('/:id/complete', verifyToken, async (req, res) => {
  try {
    const pickup = await PickupRequest.findById(req.params.id);

    if (!pickup) {
      return res.status(404).json({ message: 'Pickup not found' });
    }

    if (pickup.assignedRecycler?.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Unauthorized action' });
    }

    pickup.status = 'Completed';
    await pickup.save();

    const alreadyExists = await Inventory.findOne({ sourcePickupId: pickup._id });
    if (!alreadyExists) {
      const inventoryItem = new Inventory({
        itemName: pickup.itemName,
        category: pickup.category,
        quantity: pickup.quantity,
        condition: pickup.deviceCondition || 'Unknown',
        addedBy: req.user.id,
        sourcePickupId: pickup._id,
        status: 'Completed',
      });

      await inventoryItem.save();
    }

    res.status(200).json({ message: 'Pickup completed and added to inventory.' });
  } catch (err) {
    console.error('Error completing pickup:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
