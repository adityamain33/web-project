import express from "express";
import {
  getPlans,
  subscribeToPlan,
  getMySubscription,
} from "../controllers/subscriptionController.js";
import { verifyToken } from "../middleware/authMiddleware.js";

const router = express.Router();

// Fetch all the available subscription plans
// GET /api/subscription/plans
router.get("/plans", verifyToken, getPlans);

// Subscribe the current user to a plan
// POST /api/subscription/subscribe
router.post("/subscribe", verifyToken, subscribeToPlan);

// Fetch the current user's active subscription (if any) and the plan list
// GET /api/subscription/my-subscription
router.get("/my-subscription", verifyToken, getMySubscription);

// Optional alias for the same endpoint
// GET /api/subscription/status
router.get("/status", verifyToken, getMySubscription);

export default router;
