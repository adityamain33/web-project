// backend/routes/technicianDashboardRoutes.js
import mongoose from 'mongoose';
import express from 'express';
import Maintenance from '../../models/maintenanceModel.js';

const router = express.Router();

// Get dashboard stats for a technician
router.get('/dashboard/:technicianId', async (req, res) => {
  try {
    const { technicianId } = req.params;

    if (!technicianId || !mongoose.Types.ObjectId.isValid(technicianId)) {
      return res.status(400).json({ message: 'Invalid technician ID' });
    }

    // Count assigned tasks = all maintenance records assigned to this technician
    const assignedTasksCount = await Maintenance.countDocuments({ technicianId });

    // Count completed tasks = maintenance with status 'Completed'
    const completedTasksCount = await Maintenance.countDocuments({
      technicianId,
      status: 'Completed',
    });

    // Count pending maintenance with status Scheduled, In Progress, or Pending
    const pendingStatuses = ['Scheduled', 'In Progress', 'Pending'];
    const pendingMaintenanceCount = await Maintenance.countDocuments({
      technicianId,
      status: { $in: pendingStatuses },
    });

    // Get upcoming tasks: future due date and not completed, sorted ascending, limit 5
    const now = new Date();
    const upcomingTasks = await Maintenance.find({
      technicianId,
      dueDate: { $gte: now },
      status: { $ne: 'Completed' },
    })
      .sort({ dueDate: 1 })
      .limit(5)
      .select('task dueDate -_id');

    // Format upcoming tasks for frontend
    const formattedUpcomingTasks = upcomingTasks.map(t => ({
      task: t.task,
      due: t.dueDate.toISOString().split('T')[0], // yyyy-mm-dd format
    }));

    return res.json({
      assignedTasks: assignedTasksCount,
      completedTasks: completedTasksCount,
      pendingMaintenance: pendingMaintenanceCount,
      upcomingTasks: formattedUpcomingTasks,
    });
  } catch (error) {
    console.error('Error fetching technician dashboard data:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
