// technicianUpdateMaintenance.js

import express from 'express';
import mongoose from 'mongoose';
import Maintenance from '../../models/maintenanceModel.js';
import User from '../../models/User.js';
import { verifyToken } from '../../middleware/authMiddleware.js';

const router = express.Router();

router.get('/scheduled/:technicianId', verifyToken, async (req, res) => {
  try {
    const { technicianId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(technicianId)) {
      return res.status(400).json({ message: 'Invalid technician ID' });
    }

    if (req.user.id !== technicianId) {
      return res.status(403).json({ message: 'Not authorized to view these tasks' });
    }

    const technician = await User.findById(technicianId);
    console.log('Technician found:', technician);

    if (!technician || !technician.role || technician.role.toLowerCase() !== 'technician') {
      return res.status(404).json({ message: 'Technician not found or not authorized' });
    }

    const tasks = await Maintenance.find({ technicianId: technicianId })
      .populate('assetId', 'deviceName category')
      .populate('userId', 'name email')
      .populate('technicianId', 'name email')
      .sort({ scheduledDate: 1 });

    res.status(200).json(tasks);
  } catch (error) {
    console.error('Error fetching maintenance tasks:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// PATCH remains same but just ensure ObjectId in findById
// PATCH /api/technician/update-maintenance/:maintenanceId
router.patch('/update-maintenance/:maintenanceId', verifyToken, async (req, res) => {
  try {
    const { maintenanceId } = req.params;
    const { status, technicianRemark } = req.body;

    if (!mongoose.Types.ObjectId.isValid(maintenanceId)) {
      return res.status(400).json({ message: 'Invalid maintenance ID' });
    }

    const maintenance = await Maintenance.findById(maintenanceId);
    if (!maintenance) {
      return res.status(404).json({ message: 'Maintenance task not found' });
    }

    // Check if logged-in user is the assigned technician
    if (maintenance.technicianId.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to update this task' });
    }

    // Update fields
    if (status) maintenance.status = status;
    if (technicianRemark !== undefined) maintenance.technicianRemark = technicianRemark;

    await maintenance.save();

    res.status(200).json({ message: 'Maintenance updated successfully' });
  } catch (error) {
    console.error('Error updating maintenance:', error);
    res.status(500).json({ message: 'Server error' });
  }
});


export default router;
