// backend/routes/technicianAssignedTaskRoutes.js
import mongoose from 'mongoose';
import express from 'express';
import User from '../../models/User.js';
import Asset from '../../models/AssetModel.js';
import Maintenance from '../../models/maintenanceModel.js';

const router = express.Router();

// Get assigned tasks (assets) for technician
router.get('/assigned-tasks/:technicianId', async (req, res) => {
  try {
    const { technicianId } = req.params;

    if (!technicianId || !mongoose.Types.ObjectId.isValid(technicianId)) {
      return res.status(400).json({ message: 'Invalid technician ID' });
    }

    const technician = await User.findById(technicianId);
    if (!technician) {
      return res.status(404).json({ message: 'Technician not found' });
    }

    const assignedUserId = technician.assignedUser;
    if (!assignedUserId || !mongoose.Types.ObjectId.isValid(assignedUserId)) {
      return res.status(404).json({ message: 'No valid user assigned to this technician' });
    }

    const assignedUser = await User.findById(assignedUserId);
    if (!assignedUser) {
      return res.status(404).json({ message: 'Assigned user not found' });
    }

    const assets = await Asset.find({ addedBy: assignedUser._id });

    return res.json({
      user: {
        _id: assignedUser._id,
        name: assignedUser.name,
        email: assignedUser.email,
        role: assignedUser.role,
      },
      assets,
    });
  } catch (error) {
    console.error('Error fetching assigned tasks:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete asset (only by authorized technician)
router.delete('/assigned-tasks/:technicianId/delete-asset/:assetId', async (req, res) => {
  try {
    const { technicianId, assetId } = req.params;

    const technician = await User.findById(technicianId);
    if (!technician || !mongoose.Types.ObjectId.isValid(technician.assignedUser)) {
      return res.status(400).json({ message: 'Invalid technician or no assigned user' });
    }

    const asset = await Asset.findById(assetId);
    if (!asset || asset.addedBy.toString() !== technician.assignedUser.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this asset' });
    }

    await asset.deleteOne();
    res.json({ message: 'Asset deleted successfully' });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Schedule maintenance for an asset by technician
router.post('/assigned-tasks/:technicianId/schedule-maintenance/:assetId', async (req, res) => {
  try {
    const { technicianId, assetId } = req.params;
    const { issueDescription, scheduledDate, scheduledTime } = req.body;

    if (!issueDescription || !scheduledDate || !scheduledTime) {
      return res.status(400).json({ message: 'Missing required fields: issueDescription, scheduledDate, scheduledTime' });
    }

    // Validate technician
    const technician = await User.findById(technicianId);
    if (!technician || !technician.assignedUser) {
      return res.status(400).json({ message: 'Invalid technician or no user assigned' });
    }

    // Validate asset ownership
    const asset = await Asset.findById(assetId);
    if (!asset || asset.addedBy.toString() !== technician.assignedUser.toString()) {
      return res.status(403).json({ message: 'Not authorized to schedule maintenance for this asset' });
    }

    // ✅ Create maintenance record with correct userId field
    const maintenance = new Maintenance({
      assetId,
      technicianId: technicianId,
      userId: technician.assignedUser, // ✅ Correct field name
      issueDescription,
      scheduledDate,
      scheduledTime,
      status: 'Scheduled',
    });

    await maintenance.save();

    res.json({ message: 'Maintenance scheduled successfully', maintenance });
  } catch (error) {
    console.error('Error scheduling maintenance:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
