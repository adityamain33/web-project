// recyclerRoutes.js
import express from 'express';
import mongoose from 'mongoose';
import { verifyToken } from '../middleware/authMiddleware.js';
import Pickup from '../models/PickupRequest.js';

const router = express.Router();

// ♻️ Get pickups assigned to this recycler
router.get('/assigned', verifyToken, async (req, res) => {
  try {
    if (req.user.role !== 'recycler') {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }

    const assignedPickups = await Pickup.find({ assignedRecycler: req.user.id });
    res.status(200).json({ success: true, data: assignedPickups });
  } catch (error) {
    console.error('Error fetching assigned pickups:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
});

// ♻️ Update status of assigned pickup
router.put('/status/:id', verifyToken, async (req, res) => {
  try {
    if (req.user.role !== 'recycler') {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }

    const pickup = await Pickup.findById(req.params.id);

    if (!pickup) {
      return res.status(404).json({ success: false, message: 'Pickup not found' });
    }

    // Ensure recycler is assigned to this pickup
    if (!pickup.assignedRecycler || pickup.assignedRecycler.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Not authorized for this pickup' });
    }

    const { status } = req.body;

    if (!['picked', 'recycled'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }

    pickup.status = status;
    await pickup.save();

    res.status(200).json({ success: true, message: 'Pickup status updated', data: pickup });
  } catch (error) {
    console.error('Error updating pickup status:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
});

router.get('/dashboard-stats', verifyToken, async (req, res) => {
  try {
    if (req.user.role !== 'recycler') {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }

    const recyclerId = new mongoose.Types.ObjectId(req.user.id);

    const totalAssigned = await Pickup.countDocuments({ assignedRecycler: recyclerId });

    // Case-insensitive matching for status 'completed'
    const completed = await Pickup.countDocuments({
      assignedRecycler: recyclerId,
      status: { $regex: /^completed$/i }
    });

    const pending = await Pickup.countDocuments({
      assignedRecycler: recyclerId,
      status: { $not: { $regex: /^completed$/i } }
    });

    return res.status(200).json({
      success: true,
      data: { totalAssigned, completed, pending }
    });

  } catch (error) {
    console.error('Error fetching recycler stats:', error);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});


export default router;
